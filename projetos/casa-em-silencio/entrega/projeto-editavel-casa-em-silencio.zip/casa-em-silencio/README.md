# A casa em silêncio

Filme horizontal de 50 segundos. MP4 H.264, 1920 × 1080, 30 fps, sem áudio. A voz será fornecida pelo cliente; a montagem atual segue os intervalos do briefing, sem sincronização com uma gravação ainda inexistente.

## Arquivos
- `entrega/a-casa-em-silencio-1920x1080.mp4`: vídeo.
- `index.html`: composição editável, com controle de reprodução e busca.
- `src/composicao.js`: texto, duração, layouts e movimentos.
- `src/objetos.blend`: objetos 3D, materiais e iluminação. As coleções representam objetos distintos; ative a coleção desejada antes de renderizar.
- `src/modelar.py`: fonte procedural dos objetos.
- `BRIEFING.md`: escopo e mapa temporal.
- `assets/ATRIBUICOES.md`: fontes, ícones e licenças.

## Abrir a composição
Na raiz deste projeto, execute `python3 -m http.server 8000 --bind 127.0.0.1` e abra a página em um navegador local. Os recursos são locais; não há telemetria nem submissão a serviços de geração.

## Reexportar
Requer Node.js com Playwright acessível, Chromium e FFmpeg. Neste ambiente já estão disponíveis.

Em outra máquina: instale Node.js, Python 3, FFmpeg e Chromium; execute `npm ci --ignore-scripts`. Se Chromium não estiver no caminho de sistema, defina `CHROMIUM_PATH` ou instale o navegador suportado com `npx playwright install chromium`.

```sh
node src/exportar.cjs
```

O exportador inicia e encerra seu próprio servidor HTTP, gera quadros de revisão e exporta os 1.500 frames com tempo determinístico. `node src/exportar.cjs --proof` gera somente os quadros de revisão.

Para refazer os objetos: `blender -b -t 5 --python src/modelar.py`. Esse passo usa CPU e não precisa ser repetido para alterações somente de texto ou montagem. Os PNGs retidos já contêm os renders 3D e são compostos em camadas; o filme não é um render 3D integral de 1.500 quadros.

A abertura da fatura é uma sequência 3D de 25 poses, com textura local em `assets/fatura-impressao.png`. Para refazê-la após os objetos: `blender -b -t 5 --python src/abrir-fatura.py`. A sequência é composta com interpolação entre poses. O arquivo `src/abertura-fatura.blend` preserva a geometria e a textura empacotada; o script preserva a regra temporal da dobra.

As leituras do medidor são ilustrativas. Não representam medições reais. Os ícones são gratuitos e as licenças estão incluídas. Nenhum gerador externo pago foi usado.
