# Verificação da entrega

- **Verificado:** exportação concluída com código 0. MP4 H.264, 1920 × 1080 (16:9), 30 fps, 50,000 segundos, 1.500 quadros decodificados. Nenhuma faixa de áudio.
- **Verificado:** decodificação integral com FFmpeg, código 0 e nenhum erro emitido.
- **Verificado:** busca determinística no compositor. O quadro em 37,5 s é idêntico antes e depois de buscar outro instante.
- **Verificado por amostragem visual:** enquadramento e leitura nos 15 quadros de revisão (2,8; 7; 11,5; 14,8; 17,3; 20,6; 23,7; 25,7; 26,5; 27,4; 29,5; 37,5; 42,4; 44,5; 49 s). Abertura da fatura, ponteiro e extinção da chama estão implementados na composição. Quadro final também extraído e inspecionado do próprio MP4.
- **Verificado:** instalação repetível das dependências com `npm ci --ignore-scripts --no-audit --no-fund --cache /workspace/.cache/npm`.
- **Verificado:** licenças dos ícones e fonte preservadas em assets/. Nenhuma geração externa paga utilizada.
- **Não inspecionado:** reprodução visual integral em velocidade real. A inspeção de quadros e a decodificação não comprovam, sozinhas, fluidez perceptual de cada transição.
- **Pendente por escopo:** sincronização fina com a locução, pois o áudio do cliente ainda não foi fornecido. A entrega solicitada é somente animação.

## Técnica e limites
Objetos modelados e iluminados em Blender 4.3.2/Cycles; composição em Canvas/Chromium; exportação com FFmpeg 7.1.5 e Playwright 1.62.1. Os objetos são renders 3D compostos em camadas. A folha abre por 25 poses 3D interpoladas, podendo apresentar sobreposição transitória nas posições intermediárias. Chamas, fumaça, ponteiro, gota e transições são camadas animadas separadas. Não é um render 3D integral quadro a quadro.

## Ambiente
Os campos `install_script` e `start_skill` foram salvos no rascunho de configuração. Isso não publica o ambiente: a publicação continua sendo uma ação do produto nas configurações. Não foi verificada restauração em uma tarefa nova. Não foi feito envio de código ou vídeo ao GitHub nem hospedagem externa.
