# A casa consome em silêncio

## Escopo vigente
- Filme editorial horizontal, 1920 × 1080, 30 fps, 50 segundos.
- Sem faixa de áudio. O cliente fornecerá e adicionará a própria voz.
- Off-white, textura discreta, grade técnica, prata e grafite. Luz ampla e sombras suaves.
- Modelagem própria em Blender; ícones gratuitos Lucide, licenças ISC/MIT preservadas; fonte Manrope, SIL OFL.
- Render 3D dos objetos combinado com composição de movimento e tipografia determinística. Sem geração externa paga.
- Fonte editável e MP4 entregues localmente. Sem publicação externa.

## Montagem
| Tempo | Mensagem / ação |
|---|---|
| 00–05 | Poucas pessoas percebem isso... / introdução da fatura |
| 05–09 | Mas a sua casa fala com você. / composição dos três consumos |
| 09–13 | Ela fala na conta de energia que aumenta. / fatura |
| 13–16 | Na água desperdiçada. / torneira, gota e onda |
| 16–19 | E no gás que acaba. / queimador, chama e extinção |
| 19–22 | O problema? Ela sempre fala tarde demais. |
| 22–25 | Hoje, a casa consome em silêncio. A conta é que grita. |
| 25–33 | Segunda-feira. / fatura aberta com mãos estilizadas |
| 33–41 | Quarta-feira. / medidor em movimento contínuo |
| 41–46 | Domingo. / chama se extingue |
| 46–50 | Três surpresas. Uma única causa: Falta de informação. |

Textos sem valores monetários ou estatísticas inventadas. Leituras do medidor são elementos ilustrativos, não dados reais. A sincronização fina com a voz depende do áudio ainda não fornecido.
