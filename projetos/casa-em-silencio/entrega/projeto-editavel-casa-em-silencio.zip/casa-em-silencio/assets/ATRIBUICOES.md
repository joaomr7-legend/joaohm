# Recursos

- Ícones Lucide, https://github.com/lucide-icons/lucide — commit 20aef31db93fe4d9f398dbb15b120d99c48eef95. Licenças ISC e MIT (ícones derivados de Feather), preservadas em `icons/LICENSE`.
- Manrope, Google Fonts — licença SIL OFL em `fonts/OFL.txt`.
- Objetos 3D: modelados proceduralmente para este projeto, sem modelos externos.
