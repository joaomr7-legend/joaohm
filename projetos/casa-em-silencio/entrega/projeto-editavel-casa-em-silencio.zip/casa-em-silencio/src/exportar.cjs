// node src/exportar.cjs [--proof] — Chromium + FFmpeg, exportação determinística.
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),http=require('http'),{spawn}=require('child_process'),{once}=require('events');
const ROOT=path.resolve(__dirname,'..');
const types={'.html':'text/html','.js':'text/javascript','.png':'image/png','.svg':'image/svg+xml','.ttf':'font/ttf'};
async function main(){
 const server=http.createServer((req,res)=>{let p=path.resolve(ROOT,'.'+decodeURIComponent(req.url.split('?')[0]==='/'?'/index.html':req.url.split('?')[0]));if(!p.startsWith(ROOT+path.sep)){res.writeHead(403);res.end();return}fs.readFile(p,(e,b)=>{res.writeHead(e?404:200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});res.end(e?'Not found':b)})});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const executablePath=process.env.CHROMIUM_PATH||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
 const browser=await chromium.launch({executablePath,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--font-render-hinting=none']});
 try{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
  page.on('pageerror',e=>{throw e});
  await page.goto(`http://127.0.0.1:${server.address().port}/?export`,{waitUntil:'networkidle'});
  await page.evaluate(()=>window.ready);
  const crypto=require('crypto');
  const sample=async t=>page.evaluate(t=>{window.renderFrame(t);return document.getElementById('film').toDataURL()},t);
  const first=await sample(37.5);await sample(2.8);const again=await sample(37.5);
  if(first!==again)throw Error('Seek determinism failed');
  console.log('SEEK_DETERMINISTICO '+crypto.createHash('sha256').update(first).digest('hex'));
  const proofTimes=[2.8,7,11.5,14.8,17.3,20.6,23.7,25.7,26.5,27.4,29.5,37.5,42.4,44.5,49];
  for(const t of proofTimes){await page.evaluate(t=>window.renderFrame(t),t);await page.locator('canvas').screenshot({path:path.join(ROOT,'entrega',`quadro-${String(t).replace('.','-')}.png`)});}
  console.log('QUADROS_DE_REVISAO_PRONTOS');
  if(process.argv.includes('--proof'))return;
  const out=path.join(ROOT,'entrega/a-casa-em-silencio-1920x1080.mp4');
  const encoder=spawn('ffmpeg',['-hide_banner','-loglevel','warning','-y','-f','image2pipe','-vcodec','mjpeg','-framerate','30','-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-threads','4','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});
  let encoderError;encoder.on('error',e=>encoderError=e);encoder.stdin.on('error',e=>encoderError=e);
  const completed=once(encoder,'close');
  for(let frame=0;frame<1500;frame++){
    if(encoderError)throw encoderError;
    const jpg=await page.evaluate(t=>{window.renderFrame(t);return document.getElementById('film').toDataURL('image/jpeg',.985).split(',')[1]},frame/30);
    if(!encoder.stdin.write(Buffer.from(jpg,'base64')))await once(encoder.stdin,'drain');
    if(frame%150===0)console.log(`FRAME ${frame}/1500`);
  }
  encoder.stdin.end();const [code]=await completed;if(code!==0)throw Error('FFmpeg exit '+code);
  console.log('EXPORTADO '+out);
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1});
