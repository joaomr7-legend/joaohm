/* Composição determinística. Todos os movimentos dependem exclusivamente de t. */
const canvas=document.getElementById('film'),ctx=canvas.getContext('2d',{alpha:false});
const W=1920,H=1080,INK='#292d30',MUTED='#737877',PAPER='#f1f0eb';
const images={};
const poseCanvas=document.createElement('canvas');poseCanvas.width=1000;poseCanvas.height=1000;
const poseCtx=poseCanvas.getContext('2d');
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const ease=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10)};
const lerp=(a,b,t)=>a+(b-a)*t;
function loadImage(key,url){return new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>{images[key]=i;resolve()};i.onerror=()=>reject(Error(url));i.src=url})}
window.ready=Promise.all([
 ...['torneira','gota','fogao','medidor','fatura','fatura-maos'].map(n=>loadImage(n,'assets/renders/'+n+'.png')),
 ...Array.from({length:25},(_,i)=>{const n='abertura-'+String(i).padStart(2,'0');return loadImage(n,'assets/renders/'+n+'.png')}),
 ...['zap','droplet','flame','house','arrow-up-right'].map(n=>loadImage(n,'assets/icons/'+n+'.svg')),
 new FontFace('Manrope','url(assets/fonts/Manrope[wght].ttf)',{weight:'200 800'}).load().then(f=>document.fonts.add(f))
]).then(()=>{window.renderFrame(0);return true});

// Grain fixe et très fin; pas de scintillement aléatoire entre les images.
const grain=document.createElement('canvas');grain.width=960;grain.height=540;
const gx=grain.getContext('2d');let seed=1729;const pix=gx.createImageData(960,540);
for(let i=0;i<pix.data.length;i+=4){seed=(Math.imul(1664525,seed)+1013904223)>>>0;const v=seed>>>24;pix.data[i]=pix.data[i+1]=pix.data[i+2]=v;pix.data[i+3]=5}gx.putImageData(pix,0,0);

function font(size=20,weight=400){ctx.font=`${weight} ${size}px Manrope, sans-serif`}
function tracked(text,x,y,size=15,spacing=3,color=MUTED,weight=500){ctx.fillStyle=color;font(size,weight);let dx=x;for(const c of text){ctx.fillText(c,dx,y);dx+=ctx.measureText(c).width+spacing}}
function line(x1,y1,x2,y2,color='#b8bcb7',width=1){ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke()}
function roundRect(x,y,w,h,r=16,fill='#f7f6f2'){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill()}
function icon(n,x,y,size=26,alpha=.75){ctx.save();ctx.globalAlpha*=alpha;ctx.drawImage(images[n],x,y,size,size);ctx.restore()}

function background(t){
 ctx.fillStyle=PAPER;ctx.fillRect(0,0,W,H);
 const grad=ctx.createRadialGradient(1330,410,90,1100,540,1220);grad.addColorStop(0,'#faf9f5');grad.addColorStop(1,'#e8e8e2');ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
 ctx.save();ctx.translate(7*Math.sin(t*.055),5*Math.cos(t*.07));
 for(let x=-64;x<W+64;x+=64)line(x,0,x,H,'rgba(80,85,80,.037)');
 for(let y=-64;y<H+64;y+=64)line(0,y,W,y,'rgba(80,85,80,.037)');
 for(let x=128;x<W;x+=256)for(let y=128;y<H;y+=256){line(x-4,y,x+4,y,'rgba(80,85,80,.10)');line(x,y-4,x,y+4,'rgba(80,85,80,.10)')}
 ctx.restore();ctx.drawImage(grain,0,0,W,H);
}

function chrome(t,index){
 line(94,105,1826,105,'#c6c9c2');
 tracked('A CASA',96,67,17,4,INK,650);tracked('EM SILÊNCIO',231,67,17,4,INK,400);
 ctx.fillStyle=INK;ctx.beginPath();ctx.arc(1795,61,4,0,Math.PI*2);ctx.fill();
 tracked('UM OLHAR SOBRE O CONSUMO',1400,67,12,2,MUTED);
 line(94,979,1826,979,'#c6c9c2');
 tracked(t<25?'01 / OS SINAIS':t<46?'02 / OS TRÊS TEMPOS':'03 / A CAUSA',96,1019,12,2,MUTED);
 // Progresso de capítulo, sem distração de contadores na composição.
 for(let i=0;i<3;i++)line(1594+i*80,1015,1650+i*80,1015,i==index?INK:'#c3c6c0',i==index?2:1);
}

function shadow(x,y,rx,ry,alpha=.14){ctx.save();ctx.translate(x,y);ctx.scale(rx,ry);let g=ctx.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,`rgba(30,34,35,${alpha})`);g.addColorStop(.45,`rgba(30,34,35,${alpha*.50})`);g.addColorStop(1,'rgba(30,34,35,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,1,0,Math.PI*2);ctx.fill();ctx.restore()}
function guide(cx,cy,r,t){ctx.save();ctx.strokeStyle='rgba(85,95,93,.12)';ctx.lineWidth=1;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy,r+16,-.7+t*.004,.9+t*.004);ctx.stroke();line(cx-r-35,cy,cx-r+10,cy,'#bfc4bd');line(cx+r-10,cy,cx+r+35,cy,'#bfc4bd');ctx.restore()}

function asset(name,cx,cy,size,t,{rotate=0,float=true,alpha=1}={}){
 ctx.save();ctx.globalAlpha*=alpha;ctx.translate(cx,cy+(float?Math.sin(t*.7)*7:0));ctx.rotate(rotate);ctx.drawImage(images[name],-size/2,-size/2,size,size);ctx.restore();
}
function typeLines(lines,x,y,t,opts={}){
 const size=opts.size||74, leading=opts.leading||1.20,weight=opts.weight||380;
 lines.forEach((str,i)=>{
   let e=ease((t-i*.095)/.85);ctx.save();ctx.globalAlpha*=e;
   ctx.beginPath();ctx.rect(x-2,y+i*size*leading-size*1.1,1050,size*1.42);ctx.clip();
   font(size,weight);ctx.fillStyle=opts.color||INK;ctx.fillText(str,x,y+i*size*leading+(1-e)*48);ctx.restore();
 });
}
function eyebrow(text,x,y,t,ico){let e=ease(t/.7);ctx.save();ctx.globalAlpha*=e; if(ico){icon(ico,x,y-18,22);x+=38}tracked(text,x,y,13,2.6,MUTED,600);ctx.restore()}
function label(text,x,y){tracked(text,x,y,12,2,'#777e7a',500)}

// O único líquido em movimento é uma gota de geometria 3D com onda de impacto.
function drop(cx,cy,size,t){let phase=((t%2.8)+2.8)%2.8;
 if(phase<1.35){const fall=ease(phase/1.35);const y=cy+fall*345;asset('gota',cx,y,size*(.78+fall*.12),0,{float:false,alpha:1-ease((phase-1.15)/.2)});}
 const ripple=clamp((phase-1.13)/1.4);if(ripple>0){ctx.save();ctx.globalAlpha*=Math.sin(ripple*Math.PI)*.25;ctx.strokeStyle='#68716e';ctx.lineWidth=1.2;ctx.beginPath();ctx.ellipse(cx,cy+367,20+ripple*92,4+ripple*16,0,0,Math.PI*2);ctx.stroke();ctx.restore()}
}

function flames(cx,cy,scale,t,intensity=1){
 if(intensity<.004)return;
 ctx.save();ctx.translate(cx,cy);ctx.scale(scale,scale);
 for(let i=0;i<17;i++){
  const a=i*Math.PI*2/17;const x=Math.cos(a)*112, y=Math.sin(a)*35;
  const flicker=1+.10*Math.sin(t*7.2+i*1.7)+.045*Math.sin(t*13+i);
  const h=(57+14*Math.sin(i*4.3))*flicker*intensity;
  ctx.save();ctx.translate(x,y);const g=ctx.createLinearGradient(0,0,0,-h);g.addColorStop(0,'rgba(224,224,224,.85)');g.addColorStop(.32,'rgba(174,174,174,.82)');g.addColorStop(.7,'rgba(102,102,102,.60)');g.addColorStop(1,'rgba(70,70,70,0)');ctx.fillStyle=g;
  ctx.beginPath();ctx.moveTo(-9,0);ctx.bezierCurveTo(-17,-h*.35,-3+Math.sin(t*5+i)*3,-h*.8,3*Math.sin(i+t*3),-h);ctx.bezierCurveTo(2,-h*.65,14,-h*.32,9,0);ctx.closePath();ctx.fill();
  ctx.fillStyle='rgba(235,240,241,.6)';ctx.beginPath();ctx.ellipse(0,-3,4,8,0,0,Math.PI*2);ctx.fill();ctx.restore();
 }
 ctx.restore();
}
function smoke(cx,cy,t,start){const dt=t-start;if(dt<0||dt>2.2)return;ctx.save();ctx.globalAlpha*=Math.sin(dt/2.2*Math.PI)*.10;for(let j=0;j<8;j++){const x=cx+Math.sin(dt*1.5+j)*18,y=cy-dt*42-j*7;const g=ctx.createRadialGradient(x,y,0,x,y,20+dt*12);g.addColorStop(0,'#6e7777');g.addColorStop(1,'rgba(110,119,119,0)');ctx.fillStyle=g;ctx.fillRect(x-50,y-50,100,100)}ctx.restore()}

function hero(name,t,opts={}){
 const cx=opts.cx||1365, cy=opts.cy||558, size=opts.size||830;
 guide(cx,cy,278,t);shadow(cx,cy+302,262,30,.15);
 asset(name,cx,cy,size,t,{rotate:opts.rotate||Math.sin(t*.22)*.013});
}

function opening(t){
 eyebrow('O QUE PASSA DESPERCEBIDO',100,294,t,'house');
 typeLines(['Poucas pessoas','percebem isso...'],96,437,t-.12,{size:78});
 const p=ease((t-.35)/1.4);ctx.save();ctx.globalAlpha*=p;ctx.translate((1-p)*70,0);hero('fatura',t,{size:880,cy:550});ctx.restore();
 label('01 — ENERGIA',1204,900);
}
function house(t){
 eyebrow('SINAIS COTIDIANOS',100,294,t,'house');typeLines(['Mas a sua casa','fala com você.'],96,437,t-.1,{size:78});
 const small=545;guide(1385,545,280,t);
 shadow(1360,849,290,33,.13);
 const p=ease(t/1.2);ctx.save();ctx.globalAlpha*=p;
 asset('fatura',1150,539,small,t,{rotate:-.09});asset('torneira',1500,440,small,t,{rotate:.04});asset('fogao',1425,731,small*.9,t,{rotate:-.04});ctx.restore();
}
function energy(t){eyebrow('01 / ENERGIA',100,294,t,'zap');typeLines(['Ela fala na conta de','energia que aumenta.'],96,432,t-.1,{size:64,leading:1.27});hero('fatura',t+8,{size:890});
 ctx.save();ctx.globalAlpha*=ease(t/.8);line(1114,879,1572,879,'#b7beb7');label('CONSUMO',1120,910);icon('arrow-up-right',1540,894,24);ctx.restore();}
function water(t){eyebrow('02 / ÁGUA',100,294,t,'droplet');typeLines(['Na água','desperdiçada.'],96,437,t-.1,{size:84});hero('torneira',t,{cy:532,size:890});drop(1505,443,100,t);label('O DESPERDÍCIO NEM SEMPRE FAZ BARULHO',1088,909)}
function gas(t){eyebrow('03 / GÁS',100,294,t,'flame');typeLines(['E no gás','que acaba.'],96,437,t-.1,{size:84});hero('fogao',t,{cy:570,size:860});flames(1365,540,1.07,t,1-ease((t-1.4)/.35));smoke(1365,505,t,1.72);label('QUANDO VOCÊ PERCEBE, JÁ ACONTECEU',1100,909)}
function late(t){
 eyebrow('O TEMPO DA INFORMAÇÃO',100,273,t);
 typeLines(['O problema?'],96,414,t,{size:83,weight:550});
 typeLines(['Ela sempre fala','tarde demais.'],100,528,t-.3,{size:62,leading:1.2});
 const cx=1395,cy=529;guide(cx,cy,242,t);ctx.save();ctx.translate(cx,cy);
 for(let i=0;i<60;i++){const a=i*Math.PI/30;line(Math.sin(a)*219,-Math.cos(a)*219,Math.sin(a)*(i%5?226:235),-Math.cos(a)*(i%5?226:235),i%5?'#b4bab4':'#6c7570',i%5?1:2)}
 const a=-.5+t*.17;line(0,0,Math.sin(a)*165,-Math.cos(a)*165,INK,3);line(0,0,-60,24,INK,5);ctx.fillStyle=INK;ctx.beginPath();ctx.arc(0,0,7,0,Math.PI*2);ctx.fill();ctx.restore();
}
function silent(t){
 eyebrow('O CUSTO DO SILÊNCIO',100,284,t);
 typeLines(['Hoje, a casa consome','em silêncio.'],96,427,t,{size:68});
 typeLines(['A conta é que grita.'],100,647,t-.35,{size:70,weight:650});
 hero('fatura',t,{size:780,cx:1430,cy:543});
}

function panel(t,day,num,category,ico,kind){
 const e=ease(t/.85);ctx.save();ctx.translate((1-e)*170,0);ctx.globalAlpha*=e;
 ctx.save();ctx.shadowColor='rgba(35,42,39,.085)';ctx.shadowBlur=48;ctx.shadowOffsetY=18;roundRect(94,156,1732,770,22,'#f8f7f2');ctx.restore();
 ctx.save();ctx.beginPath();ctx.roundRect(94,156,1732,770,22);ctx.clip();
 const gg=ctx.createLinearGradient(1000,0,1826,0);gg.addColorStop(0,'rgba(233,234,227,0)');gg.addColorStop(1,'rgba(226,229,223,.6)');ctx.fillStyle=gg;ctx.fillRect(1000,156,826,770);
 for(let x=1050;x<1840;x+=48)line(x,156,x,926,'rgba(103,113,104,.035)');
 for(let y=156;y<950;y+=48)line(970,y,1826,y,'rgba(103,113,104,.035)');
 ctx.restore();
 ctx.strokeStyle='#dedfd7';ctx.lineWidth=1;ctx.beginPath();ctx.roundRect(94,156,1732,770,22);ctx.stroke();
 line(945,228,945,849,'#dcdfd7');
 tracked('TRÊS TEMPOS / '+num,153,226,12,2.4,MUTED);
 ctx.save();ctx.globalAlpha*=.065;font(224,300);ctx.fillStyle=INK;ctx.fillText(num,139,497);ctx.restore();
 eyebrow(category.toUpperCase(),160,586,t-.15,ico);
 typeLines([day],155,688,t-.13,{size:73,weight:480});
 line(160,744,368,744,'#aab2aa');
 // Discrète signature de catégorie, sans données de consommation inventées.
 icon(ico,160,815,25,.7);label(category.toUpperCase(),203,835);
 const cx=1387,cy=536;guide(cx,cy,263,t);
 shadow(cx,829,245,30,.12);
 if(kind==='bill'){
   // Révélation de la feuille par retrait de la main et déploiement en perspective.
   const reveal=ease((t-.45)/1.75),frame=clamp((t-.45)/1.75)*24;
   const a=Math.floor(frame),b=Math.min(24,a+1),mix=frame-a;
   ctx.save();ctx.translate(cx,cy+15*(1-reveal));ctx.rotate(lerp(-.04,-.015,reveal));
   const size=820+reveal*30;
   // Poses 3D adjacentes são interpoladas; a última pose fica sustentada.
   const lower=images['abertura-'+String(a).padStart(2,'0')],upper=images['abertura-'+String(b).padStart(2,'0')];
   poseCtx.clearRect(0,0,1000,1000);poseCtx.globalCompositeOperation='source-over';poseCtx.globalAlpha=1-mix;poseCtx.drawImage(lower,0,0,1000,1000);
   poseCtx.globalCompositeOperation='lighter';poseCtx.globalAlpha=mix;poseCtx.drawImage(upper,0,0,1000,1000);poseCtx.globalAlpha=1;poseCtx.globalCompositeOperation='source-over';
   ctx.drawImage(poseCanvas,-size/2,-size/2,size,size);
   ctx.restore();
   const p=ease((t-1.5)/.9);ctx.save();ctx.globalAlpha*=p;label('A CONTA CHEGA.',1181,875);ctx.restore();
 }else if(kind==='meter'){
   asset('medidor',cx,cy,860,0,{float:false});
   // O ponteiro é uma camada independente do corpo 3D, em rotação contínua.
   const px=cx-7,py=cy+80;ctx.save();ctx.translate(px,py);ctx.rotate(t*2.65);ctx.fillStyle='#434c51';ctx.beginPath();ctx.moveTo(-4,12);ctx.lineTo(-3,-103);ctx.lineTo(0,-117);ctx.lineTo(3,-103);ctx.lineTo(4,12);ctx.closePath();ctx.fill();ctx.fillStyle='#afb6b8';ctx.beginPath();ctx.arc(0,0,7,0,Math.PI*2);ctx.fill();ctx.restore();
   label('O FLUXO CONTINUA.',1177,875);
 }else{
   asset('fogao',cx,cy+40,850,t,{rotate:0});
   const power=(ease((t-.25)/.45))*(1-ease((t-2.7)/.16));
   flames(cx,cy+7,1.03,t,power);smoke(cx,cy-20,t,2.86);
   ctx.save();ctx.globalAlpha*=ease((t-2.85)/.5);label('A CHAMA SE APAGA.',1174,875);ctx.restore();
 }
 ctx.restore();
}

function ending(t){
 const p=ease(t/.85);
 // Les trois objets convergent vers une seule signature visuelle.
 const y=365;
 shadow(960,533,300,20,.12);
 asset('fatura',lerp(510,795,p),y,385,t,{rotate:lerp(-.19,-.08,p)});
 asset('torneira',lerp(1410,1125,p),y-17,385,t,{rotate:lerp(.12,.02,p)});
 asset('fogao',960,lerp(600,447,p),347,t,{rotate:0});
 ctx.save();ctx.textAlign='center';
 font(63,400);ctx.fillStyle=INK;ctx.globalAlpha*=ease((t-.15)/.75);ctx.fillText('Três surpresas.',960,651);
 ctx.globalAlpha=1;ctx.globalAlpha*=ease((t-.55)/.8);font(30,400);ctx.fillStyle=MUTED;ctx.fillText('Uma única causa:',960,718);
 ctx.globalAlpha=1;ctx.globalAlpha*=ease((t-.85)/.85);font(73,650);ctx.fillStyle=INK;ctx.fillText('Falta de informação.',960,813);ctx.restore();
 line(864,865,1056,865,'#929c93');
}

const scenes=[
 {s:0,e:5,draw:opening},{s:5,e:9,draw:house},{s:9,e:13,draw:energy},
 {s:13,e:16,draw:water},{s:16,e:19,draw:gas},{s:19,e:22,draw:late},
 {s:22,e:25,draw:silent},
 {s:25,e:33,draw:t=>panel(t,'Segunda-feira.','01','Energia','zap','bill')},
 {s:33,e:41,draw:t=>panel(t,'Quarta-feira.','02','Água','droplet','meter')},
 {s:41,e:46,draw:t=>panel(t,'Domingo.','03','Gás','flame','gas')},
 {s:46,e:50,draw:ending}
];
window.renderFrame=function(t){
 t=clamp(t,0,49.999999);ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.textAlign='left';background(t);
 for(let i=0;i<scenes.length;i++){
  const s=scenes[i],overlap=.34;
  if(t<s.s||t>=s.e+overlap)continue;
  let alpha=i===0?1:ease((t-s.s)/overlap);
  if(t>s.e)alpha*=1-ease((t-s.e)/overlap);
  ctx.save();ctx.globalAlpha=alpha;
  if(t>s.e)ctx.translate(-ease((t-s.e)/overlap)*70,0);
  s.draw(t-s.s);ctx.restore();
 }
 chrome(t,t<25?0:t<46?1:2);
};
let playing=false,current=0,origin=0;
const play=document.getElementById('play'),seek=document.getElementById('seek'),clock=document.getElementById('time');
function controls(){seek.value=current;clock.textContent=`00:${String(Math.floor(current)).padStart(2,'0')} / 00:50`}
function tick(now){if(!playing)return;current=(now-origin)/1000;if(current>=50){current=49.999;playing=false;play.textContent='Reproduzir'}window.renderFrame(current);controls();if(playing)requestAnimationFrame(tick)}
play.onclick=()=>{playing=!playing;play.textContent=playing?'Pausar':'Reproduzir';if(playing){if(current>=49.9)current=0;origin=performance.now()-current*1000;requestAnimationFrame(tick)}};
seek.oninput=()=>{current=Number(seek.value);origin=performance.now()-current*1000;window.renderFrame(current);controls()};
if(new URLSearchParams(location.search).has('export'))document.body.classList.add('export');
