#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 src/compor-effectcraft.py
/workspace/tools/bin/effectcraft-cli render filme-3d-effectcraft.ecproj --comp MASTER_HORIZONTAL_1920x1080 --out entrega/casa-v3-horizontal-nativo.mp4 --audio off --progress --json
ffmpeg -hide_banner -loglevel error -y -i entrega/casa-v3-horizontal-nativo.mp4 -an -c:v libx264 -preset fast -crf 17 -profile:v main -pix_fmt yuv420p -threads 3 -movflags +faststart entrega/casa-v3-horizontal.mp4
ffmpeg -hide_banner -loglevel error -y -i entrega/casa-v3-horizontal.mp4 -an -vf 'crop=608:1080:656:0,scale=1080:1920:flags=lanczos' -c:v libx264 -preset fast -crf 17 -profile:v main -pix_fmt yuv420p -threads 3 -movflags +faststart entrega/casa-v3-vertical.mp4
