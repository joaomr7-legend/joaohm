const {chromium}=require('playwright');const fs=require('fs'),path=require('path'),http=require('http'),{spawn}=require('child_process'),{once}=require('events');
const ROOT=path.resolve(__dirname,'..');
async function main(){
 const types={'.html':'text/html','.js':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.png':'image/png'};
 const server=http.createServer((req,res)=>{const target=path.resolve(ROOT,'.'+decodeURIComponent(req.url.split('?')[0]==='/'?'/index.html':req.url.split('?')[0]));if(!target.startsWith(ROOT+path.sep)){res.writeHead(403);res.end();return}fs.readFile(target,(e,b)=>{res.writeHead(e?404:200,{'Content-Type':types[path.extname(target)]||'application/octet-stream'});res.end(e?'Not found':b)})});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader','--font-render-hinting=none']});
 try{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});let error;
  page.on('pageerror',e=>error=e);await page.goto(`http://127.0.0.1:${server.address().port}`,{waitUntil:'networkidle',timeout:120000});
  const info=await page.evaluate(()=>window.ready);console.log('CENA_3D',JSON.stringify(info));if(error)throw error;
  for(const t of [2.5,10.5,14,17,23.5,28,37,43,44.5,49]){
   await page.evaluate(t=>window.renderFrame(t),t);
   await page.locator('canvas').screenshot({path:path.join(ROOT,'entrega',`cena-${String(t).replace('.','-')}.png`)});
  }
  console.log('QUADROS_3D_PRONTOS');if(process.argv.includes('--proof'))return;
  const output=path.join(ROOT,'assets/cena-3d.mp4');
  const encoder=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','image2pipe','-vcodec','mjpeg','-framerate','30','-i','pipe:0','-an','-vf','scale=in_range=pc:out_range=tv,format=yuv420p','-c:v','libx264','-preset','fast','-crf','17','-profile:v','main','-color_range','tv','-threads','3','-movflags','+faststart',output],{stdio:['pipe','inherit','inherit']});
  const done=once(encoder,'close');let pipeError;encoder.stdin.on('error',e=>pipeError=e);
  const start=Date.now();
  for(let i=0;i<1500;i++){
   if(error)throw error;if(pipeError)throw pipeError;
   const b64=await page.evaluate(t=>{window.renderFrame(t);return window.canvas.toDataURL('image/jpeg',.985).split(',')[1]},i/30);
   if(!encoder.stdin.write(Buffer.from(b64,'base64')))await once(encoder.stdin,'drain');
   if(i%25===0)console.log(`FRAME ${i}/1500 ${((Date.now()-start)/1000).toFixed(1)}s`);
  }
  encoder.stdin.end();const [code]=await done;if(code)throw Error('FFmpeg exit '+code);console.log('RENDER_3D_CONCLUIDO',output);
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1});
