"""Cena 3D original, com câmera e animação editáveis no Blender.

Exporta GLB animado para renderização PBR gratuita e determinística no navegador.
"""
import bpy, math, json
from pathlib import Path
from mathutils import Vector

P=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.fps=30;s.frame_start=1;s.frame_end=1501
s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100
s.world.color=(.8,.78,.73)
parent=None
def mat(name,c,metal=0,rough=.4):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True
 bs=m.node_tree.nodes['Principled BSDF'];bs.inputs['Base Color'].default_value=(*c,1);bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=rough
 return m
silver=mat('Prata polida',(.43,.46,.48),.93,.19)
dark=mat('Metal grafite',(.035,.045,.052),.78,.24)
black=mat('Cerâmica escura',(.015,.021,.025),.35,.26)
white=mat('Papel marfim',(.86,.85,.81),0,.65)
humanmat=mat('Figuras em metal escuro',(.065,.078,.084),.6,.32)
def root(name):
 o=bpy.data.objects.new(name,None);s.collection.objects.link(o);return o
def finish(o,name,material,bevel=0):
 o.name=name;o.parent=parent
 if material:o.data.materials.append(material)
 if bevel:
  b=o.modifiers.new('Arestas suaves','BEVEL');b.width=bevel;b.segments=3
  o.modifiers.new('Normais ponderadas','WEIGHTED_NORMAL')
 if o.type=='MESH':
  for f in o.data.polygons:f.use_smooth=True
 return o
def cube(name,loc,dim,m,bevel=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,m,bevel)
def sphere(name,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=loc);o=bpy.context.object;o.scale=scale;return finish(o,name,m)
def cylinder(name,loc,r,d,m,rot=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=r,depth=d,location=loc);o=bpy.context.object
 if rot:o.rotation_euler=rot
 return finish(o,name,m,.012)
def tube(name,pts,r,m):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=3;c.resolution_u=12
 sp=c.splines.new('BEZIER');sp.bezier_points.add(len(pts)-1)
 for a,p in zip(sp.bezier_points,pts):a.co=p;a.handle_left_type='AUTO';a.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);s.collection.objects.link(o);o.parent=parent;c.materials.append(m);return o
def borrow(collection,name):
 global parent
 old=P/'assets/base-objetos.blend'
 with bpy.data.libraries.load(str(old),link=False) as (a,b):b.collections=[collection]
 col=b.collections[0];s.collection.children.link(col);col.hide_render=False
 r=root(name)
 for o in col.objects:o.parent=r
 return r

papertex=bpy.data.images.load(str(P/'assets/fatura-impressao.png'));papertex.pack()
pm=mat('Fatura / impressão própria',(.95,.94,.90),0,.61)
nd=pm.node_tree.nodes.new('ShaderNodeTexImage');nd.image=papertex;pm.node_tree.links.new(nd.outputs['Color'],pm.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
def bill(name):
 global parent
 r=root(name);parent=r
 nx,nz=12,48;vs=[];fs=[]
 for j in range(nz+1):
  z=j/nz*1.9
  for i in range(nx+1):
   x=(i/nx-.5)*1.35;y=.035*math.sin(z*2.3)+.13*max(0,1-z/.4)**2
   vs.append((x,y,z))
 for j in range(nz):
  for i in range(nx):
   a=j*(nx+1)+i;fs.append((a,a+1,a+nx+2,a+nx+1))
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();uv=me.uv_layers.new()
 for p in me.polygons:
  for li in p.loop_indices:
   vi=me.loops[li].vertex_index;uv.data[li].uv=(vi%(nx+1)/nx,vi//(nx+1)/nz)
 o=bpy.data.objects.new(name+' / folha curva',me);s.collection.objects.link(o);o.parent=r;o.data.materials.append(pm)
 sol=o.modifiers.new('Espessura do papel','SOLIDIFY');sol.thickness=.009
 for p in me.polygons:p.use_smooth=True
 parent=None;return r

mainbill=bill('FATURA_PRINCIPAL')
parent=None;tap=root('TORNEIRA_CLASSICA');parent=tap
cylinder('Roseta',(0,.25,1.18),.20,.13,silver,(math.pi/2,0,0))
tube('Bica',[(0,.20,1.18),(0,-.13,1.18),(0,-.45,1.10),(0,-.52,.92)],.095,silver)
cylinder('Aerador',(0,-.52,.90),.109,.09,dark)
cylinder('Interior da bica',(0,-.52,.848),.076,.018,black)
cylinder('Coluna da válvula',(0,.02,1.38),.085,.35,silver)
handle=root('VOLANTE_DA_TORNEIRA');handle.parent=tap;handle.location=(0,.02,1.58);parent=handle
cube('Volante horizontal',(0,0,0),(.48,.065,.075),dark,.03)
cube('Volante transversal',(0,0,0),(.065,.48,.075),dark,.03)
for x,y in [(-.24,0),(.24,0),(0,.24),(0,-.24)]:sphere('Ponta do volante',(x,y,0),(.057,.057,.057),silver)
parent=None
drop=root('GOTA');drop.parent=tap;parent=drop
o=sphere('Gota metálica',(0,0,0),(.073,.073,.11),silver)
o=sphere('Ponta da gota',(0,0,.085),(.033,.033,.075),silver)
parent=None

stove=borrow('03 | Queimador','FOGAO')
meter=borrow('04 | Medidor','MEDIDOR')
needle=root('PONTEIRO');needle.parent=meter;needle.location=(0,-.455,-.30);parent=needle
cube('Lâmina do ponteiro',(0,-.01,.25),(.022,.024,.52),dark,.008)
parent=None
flames=root('CHAMAS');flames.parent=stove
flamemat=mat('Chama prateada',(.43,.60,.72),0,.4)
bs=flamemat.node_tree.nodes['Principled BSDF'];bs.inputs['Emission Color'].default_value=(.44,.62,.80,1);bs.inputs['Emission Strength'].default_value=.55;bs.inputs['Alpha'].default_value=.8
flamemat.surface_render_method='DITHERED'
parent=flames;flameparts=[]
for i in range(24):
 a=i*math.tau/24;r=.74
 ob=sphere('Língua de chama',(r*math.cos(a),r*math.sin(a),.61),(.031,.031,.14),flamemat)
 flameparts.append(ob)
parent=None

network=root('PLATAFORMAS_E_TUBULACOES');parent=network
for pts in [[(-1.9,-1.0,.04),(-1.9,.3,.04),(-.6,.3,.04),(-.6,1.3,.04)],[(1.9,1.2,.04),(1.9,-.1,.04),(.7,-.1,.04),(.7,-1.2,.04)],[(-1.8,-1.3,.04),(1.7,-1.3,.04)]]:tube('Tubulação de informação',pts,.032,silver)
cube('Plataforma principal',(0,0,.20),(2.6,2.2,.16),white,.035)
hinges=[]
for i,(x,y) in enumerate([(-1.5,0),(1.5,0),(0,1.3)]):
 h=root('PLACA_ARTICULADA_'+str(i));h.parent=network;h.location=(x,y,.13);parent=h
 cube('Placa grafite',(0,0,0),(1.28,1.6,.10),dark,.025);hinges.append(h)
parent=None
flatbill=bill('FATURA_NA_PLATAFORMA');flatbill.parent=network;flatbill.location=(0,-.8,.31);flatbill.rotation_euler.x=-math.pi/2;flatbill.scale=(.82,.82,.82)

def person(name,x,y,z=0,height=1):
 global parent
 r=root(name);r.location=(x,y,z);r.scale=(height,)*3;parent=r
 sphere('Cabeça',(0,0,.97),(.103,.093,.12),humanmat)
 cylinder('Pescoço',(0,0,.84),.05,.11,humanmat)
 o=cube('Tronco',(0,0,.65),(.27,.16,.35),humanmat,.08)
 for side in [-1,1]:
  tube('Perna',[(side*.075,0,.48),(side*.08,.015,.25),(side*.085,-.015,.08)],.048,humanmat)
  sphere('Sapato',(side*.09,-.045,.055),(.07,.12,.045),black)
  tube('Braço',[(side*.16,0,.77),(side*.20,-.015,.56),(side*.21,-.08,.43)],.036,humanmat)
  sphere('Mão',(side*.21,-.08,.42),(.043,.037,.05),humanmat)
 parent=None;return r

family=root('CARTAO_SEGUNDA');parent=family
cube('Painel de segunda',(0,.62,1.65),(2.65,.18,3.35),dark,.08)
cube('Base das figuras',(0,-.12,.10),(2.35,1.28,.13),white,.025)
parent=None
for i,(x,y,h) in enumerate([(-.77,-.20,1.15),(-.38,-.08,1.02),(.05,-.44,.63)]):
 r=person('FIGURA_FAMILIA_'+str(i),x,y,.18,h);r.parent=family
fb=bill('FATURA_DA_FAMILIA');fb.parent=family;fb.location=(.55,.22,.45);fb.rotation_euler.y=-.13;fb.scale=(.85,)*3

sunday=root('CARTAO_DOMINGO');parent=sunday
cube('Painel de domingo',(0,.63,1.55),(2.65,.18,3.16),dark,.08)
cube('Mesa de cozinha',(0,-.22,.22),(2.45,1.55,.18),white,.03)
parent=None
for i,x in enumerate([-.81,.83]):
 r=person('FIGURA_DOMINGO_'+str(i),x,.15,.30,.9);r.parent=sunday

# Piso com grade original. Sem imagens da referência.
grid=bpy.data.images.new('Grade original',width=128,height=128)
px=[]
for y in range(128):
 for x in range(128):
  c=(.785,.785,.749,1) if x==0 or y==0 else (.855,.85,.815,1)
  px.extend(c)
grid.pixels=px;grid.pack()
floor=mat('Piso de papel',(.86,.85,.81),0,.82)
te=floor.node_tree.nodes.new('ShaderNodeTexImage');te.image=grid;te.extension='REPEAT'
tc=floor.node_tree.nodes.new('ShaderNodeTexCoord');mp=floor.node_tree.nodes.new('ShaderNodeMapping');mp.inputs['Scale'].default_value=(40,40,1)
floor.node_tree.links.new(tc.outputs['UV'],mp.inputs['Vector']);floor.node_tree.links.new(mp.outputs['Vector'],te.inputs['Vector']);floor.node_tree.links.new(te.outputs['Color'],floor.node_tree.nodes['Principled BSDF'].inputs['Base Color'])
bpy.ops.mesh.primitive_plane_add(size=40,location=(0,0,-.05));o=bpy.context.object;o.name='PISO';o.data.materials.append(floor)

bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='CAMERA_CINEMA';cam.data.type='ORTHO';cam.data.ortho_scale=8.2;s.camera=cam
def smooth(t):t=max(0,min(1,t));return t*t*(3-2*t)
def window(t,a,b):return smooth((t-a)/.42)*(1-smooth((t-(b-.38))/.38))
def setroot(o,loc,scale,rot=(0,0,0)):
 o.location=loc;o.scale=(scale,)*3;o.rotation_euler=rot
 o.keyframe_insert('location');o.keyframe_insert('scale');o.keyframe_insert('rotation_euler')
zoom=[]
def camera_values(t):
 az=.30+.055*math.sin(t*.22);pitch=.58;target=Vector((0,-.05,2.28));ortho=7.7
 if t<9:target.z=1.80;ortho=7.10
 if 9<=t<13:target.z=2.0;ortho=6.2
 if 13<=t<16:target.z=1.9;ortho=6.3
 if 16<=t<19:target.z=1.8;ortho=6.2
 if 22<=t<25:az=.48+.12*smooth((t-22)/3);pitch=.82;target.z=2.12;ortho=6.9
 if 25<=t<33:az=.10+.05*math.sin((t-25)*.3);pitch=.37;target.z=2.22;ortho=6.8
 if 33<=t<41:az=.29+.07*math.sin((t-33)*.25);pitch=.65;target.z=2.00;ortho=7.1
 if 41<=t<46:az=.17+.035*math.sin((t-41)*.5);pitch=.42;target.z=2.13;ortho=6.8
 if t>=46:az=.26;pitch=.47;target.z=2.2;ortho=7.0
 return az,pitch,target,ortho+.06*math.sin(t*.37)
for f in range(1,1502):
 t=(f-1)/30;s.frame_set(f)
 first=window(t,0,9);energy=window(t,9,13);water=window(t,13,16);gas=window(t,16,19);late=window(t,19,22);end=window(t,46,50.5)
 a=first*1.0+energy*1.13+late*.26+end*.48
 bx=-.98*first-1.06*end
 setroot(mainbill,(bx,-.1,.35+1.9*end),a,(.035*math.sin(t*.4),0,-.10*first))
 a=first*1.15+water*1.25+window(t,33,41)*1.15+late*.26+end*.64
 tx=first*1.06+window(t,33,41)*.72+end*1.03
 setroot(tap,(tx,.05,.36+1.9*end),a,(0,0,.04*math.sin(t*.35)))
 a=first*.43+gas*.63+window(t,41,46)*.49+late*.20+end*.30
 sy=-.93+.38*end;sz=.12+2.45*end
 if 16<=t<19:sy=-.25;sz=.65
 if 41<=t<46:sy=-.22;sz=.325
 setroot(stove,(0,sy,sz),a,(0,0,0))
 setroot(meter,(-.68,-.10,.58),window(t,33,41)*.45,(-.63,0,-.12))
 needle.rotation_euler.y=t*2.7;needle.keyframe_insert('rotation_euler')
 handle.rotation_euler.z=.08*math.sin(t);handle.keyframe_insert('rotation_euler')
 phase=((t-.35)%1.45)/1.45
 drop.location=(0,-.52,.69-phase*phase*.59);drop.scale=((1 if phase<.82 else 0),)*3;drop.keyframe_insert('location');drop.keyframe_insert('scale')
 flame_on=1
 if 16<t<19:flame_on=1-smooth((t-17.65)/.17)
 if 41<t<46:flame_on=smooth((t-41.3)/.35)*(1-smooth((t-43.6)/.16))
 flames.scale=(1,1,flame_on);flames.keyframe_insert('scale')
 for i,ob in enumerate(flameparts):
  ob.scale.z=.14*(1+.12*math.sin(t*9+i));ob.keyframe_insert('scale')
 net=window(t,22,25)
 setroot(network,(0,0,.08),net*.8)
 for i,h in enumerate(hinges):
  h.rotation_euler.y=(.15+1.18*smooth((t-22.4)/1.2))*(-1 if i==0 else 1);h.keyframe_insert('rotation_euler')
 setroot(family,(.55*(1-smooth((t-25)/.5)),.1,0),window(t,25,33),(0,0,.025*math.sin(t*.4)))
 setroot(sunday,(.55*(1-smooth((t-41)/.5)),.1,0),window(t,41,46))
 # Câmera real: órbita lenta, passagem isométrica na plataforma e aproximações.
 az,pitch,target,ortho=camera_values(t)
 for cut in [9,13,16,19,22,25,33,41,46]:
  if cut<=t<cut+.42:
   oldaz,oldpitch,oldtarget,oldscale=camera_values(cut-.001);q=smooth((t-cut)/.42)
   az=oldaz+(az-oldaz)*q;pitch=oldpitch+(pitch-oldpitch)*q;target=oldtarget.lerp(target,q);ortho=oldscale+(ortho-oldscale)*q
 cam.location=target+Vector((math.sin(az)*math.cos(pitch)*12,-math.cos(az)*math.cos(pitch)*12,math.sin(pitch)*12))
 cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=ortho
 cam.keyframe_insert('location');cam.keyframe_insert('rotation_euler');cam.data.keyframe_insert('ortho_scale');zoom.append([round(t,6),ortho])

for obj in bpy.data.objects:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
s.frame_set(75)
# Iluminação de prévia no Blender; o render web usa iluminação equivalente e ambiente PBR.
for loc,power,size in [((-4,-4,8),1100,4),((5,2,6),850,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False
bpy.ops.wm.save_as_mainfile(filepath=str(P/'src/cena-3d.blend'))
(P/'assets/camera-zoom.json').write_text(json.dumps(zoom,separators=(',',':')))
bpy.ops.export_scene.gltf(filepath=str(P/'assets/cena-animada.glb'),export_format='GLB',export_cameras=True,export_lights=False,export_animations=True,export_animation_mode='SCENE',export_frame_range=True,export_force_sampling=True,export_apply=True)
print('CENA_GLTF_PRONTA')
