"""Exporta a cena já editada, sem reconstruir ou substituir a geometria."""
import bpy,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]
s=bpy.context.scene
if not s.camera:raise RuntimeError('Selecione a câmera ativa no Blender.')
if s.camera.data.type!='ORTHO':raise RuntimeError('O render web deste projeto usa câmera ortográfica.')
zoom=[]
for frame in range(1,1502):
 s.frame_set(frame);zoom.append([(frame-1)/30,s.camera.data.ortho_scale])
(P/'assets/camera-zoom.json').write_text(json.dumps(zoom,separators=(',',':')))
s.frame_set(1)
bpy.ops.export_scene.gltf(filepath=str(P/'assets/cena-animada.glb'),export_format='GLB',export_cameras=True,export_lights=False,export_animations=True,export_animation_mode='SCENE',export_frame_range=True,export_force_sampling=True,export_apply=True)
print('CENA_EDITADA_EXPORTADA')
