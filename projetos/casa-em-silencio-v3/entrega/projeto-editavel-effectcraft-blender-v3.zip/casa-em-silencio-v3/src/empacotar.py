from pathlib import Path
import zipfile,hashlib
P=Path(__file__).resolve().parents[1]
files=[P/x for x in ['README.md','BRIEFING.md','ANALISE-REFERENCIA.md','VERIFICACAO.md','ABRIR-O-PROJETO.txt','filme-3d-effectcraft.ecproj','index.html','package.json','package-lock.json']]
files += [P/'src'/x for x in ['modelar-cena.py','exportar-blend.py','cena-3d.blend','cena-web.js','renderizar.cjs','compor-effectcraft.py','exportar-entregas.sh','verificar-entregas.py','empacotar.py']]
files += [x for x in (P/'assets').rglob('*') if x.is_file() and x.name!='placeholder.png']
z=P/'entrega/projeto-editavel-effectcraft-blender-v3.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for f in files:out.write(f,'casa-em-silencio-v3/'+str(f.relative_to(P)))
with zipfile.ZipFile(z) as f:assert f.testzip() is None
out=[]
for f in [z,P/'entrega/casa-v3-horizontal.mp4',P/'entrega/casa-v3-vertical.mp4']:
 out.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name)
(P/'entrega/SHA256SUMS.txt').write_text('\n'.join(out)+'\n')
print('ZIP_VALIDO',z.stat().st_size,len(files))
