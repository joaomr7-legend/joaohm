import subprocess,json,pathlib
P=pathlib.Path(__file__).resolve().parents[1]
report={}
for name,size in [('horizontal',(1920,1080)),('vertical',(1080,1920))]:
 f=P/f'entrega/casa-v3-{name}.mp4'
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(f)]))
 assert len(d['streams'])==1
 s=d['streams'][0]
 assert s['codec_name']=='h264' and s['pix_fmt']=='yuv420p'
 assert (s['width'],s['height'])==size and s['r_frame_rate']=='30/1'
 assert s['nb_frames']=='1500' and abs(float(d['format']['duration'])-50)<.001
 subprocess.run(['ffmpeg','-v','error','-i',str(f),'-f','null','-'],check=True)
 report[name]={'width':s['width'],'height':s['height'],'fps':s['r_frame_rate'],'frames':s['nb_frames'],'duration':d['format']['duration'],'codec':s['codec_name'],'profile':s['profile'],'pixel_format':s['pix_fmt'],'audio':False,'decode':'OK'}
(P/'entrega/verificacao-video.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
