import json, pathlib, subprocess, shutil, sys
P=pathlib.Path(__file__).resolve().parent.parent
base=P/'assets/textos-base.ecproj'
if not base.exists():
 d=json.loads((P.parent/'casa-em-silencio-v2/filme-centralizado.ecproj').read_text())
 for k,v in list(d['items'].items()):
  if 'layers' not in v.get('kind',{}): del d['items'][k]
 for v in d['items'].values():
  v['kind']['layers']=[l for l in v['kind']['layers'] if l.get('source',{}).get('type') in ['Text','Comp']]
 base.write_text(json.dumps(d))
d=json.loads(base.read_text())
def walk(o):
 if isinstance(o,dict):
  yield o
  for v in o.values(): yield from walk(v)
 elif isinstance(o,list):
  for v in o: yield from walk(v)
def vec(layer,match,value=None,dy=None):
 for p in walk(layer['props']):
  if p.get('match')==match and p.get('value',{}).get('t')=='Vec3':
   if value is not None:p['value']['v']=value;p['keys']=[]
   if dy is not None:
    p['value']['v'][1]+=dy
    for k in p.get('keys',[]):k['value']['v'][1]+=dy
   return
items=d['items']; core=next(v for v in items.values() if v.get('name','').startswith('CORE'))
masterid=next(k for k,v in items.items() if v.get('name')=='MASTER_HORIZONTAL_1920x1080')
core['name']='CORE_TEXTOS_EDITAVEIS_608x1080'
for l in core['kind']['layers']:
 for p in walk(l['props']):
  if p.get('match')!='sourceText':continue
  doc=p['value']['v'];s=doc['text']
  if s in ['CONTA DE ENERGIA','A CHAMA SE APAGA.']:vec(l,'position',dy=62)
  if s=='Segunda-feira.':doc.update(text='SEGUNDA-FEIRA.',size=36,fill=[.95,.945,.92,1]);vec(l,'position',dy=114)
  if s=='Domingo.':doc.update(text='DOMINGO.',size=42,fill=[.95,.945,.92,1]);vec(l,'position',dy=134)
  if s=='A conta é que grita.':doc.update(text='A CONTA É\nQUE GRITA.',size=54,leading=59);vec(l,'position',dy=-108)
for v in items.values():
 if v.get('name')=='VERTICAL_1080x1920':
  for l in v['kind']['layers']:
   if l.get('source',{}).get('type')=='Comp':
    l['source']['item']=int(masterid)
    vec(l,'anchor',[960,540,0]);vec(l,'position',[540,960,0]);vec(l,'scale',[177.777777,177.777777,100])
project=P/'filme-3d-effectcraft.ecproj';project.write_text(json.dumps(d))
movie=P/'assets/cena-3d.mp4'
if not movie.exists() or "--proof" in sys.argv:
 movie=P/'assets/placeholder.png';shutil.copy(P/'entrega/cena-2-5.png',movie)
cmd=[{'command':'comp.open','params':{'comp':'MASTER_HORIZONTAL_1920x1080'}},{'command':'file.import','params':{'paths':[str(movie)],'sequence':False,'addToComp':True}},{'command':'layer.rename','params':{'name':'CENA_3D — editar em src/cena-3d.blend'}},{'command':'layer.arrange','params':{'to':'back'}},{'command':'comp.open','params':{'comp':'MASTER_HORIZONTAL_1920x1080'}}]
f=P/'src/importar-3d.json';f.write_text(json.dumps(cmd))
r=subprocess.run(['/workspace/tools/bin/effectcraft-cli','exec','file.runScript',json.dumps({'path':str(f)}),str(project),'--save','--json'],capture_output=True,text=True)
print(r.stdout,r.stderr);r.check_returncode()
d=json.loads(project.read_text())
def relative(o):
 if isinstance(o,dict):return {k:relative(v) for k,v in o.items()}
 if isinstance(o,list):return [relative(v) for v in o]
 if isinstance(o,str) and o.startswith(str(P)+'/assets/'):return 'assets/'+o.split('/assets/',1)[1]
 return o
project.write_text(json.dumps(relative(d),ensure_ascii=False))
print('PROJETO',len(core['kind']['layers']),movie.name)
