import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const renderer=new THREE.WebGLRenderer({antialias:false,alpha:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
renderer.setSize(1920,1080);renderer.setPixelRatio(1);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.94;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.VSMShadowMap;
document.body.appendChild(renderer.domElement);window.canvas=renderer.domElement;
const scene=new THREE.Scene();scene.background=new THREE.Color('#e9e6dd');
const pmrem=new THREE.PMREMGenerator(renderer);
scene.environment=pmrem.fromScene(new RoomEnvironment(),.04).texture;scene.environmentIntensity=.48;
const key=new THREE.DirectionalLight(0xfff4de,4.0);key.position.set(-4,8,5);key.castShadow=true;
key.shadow.mapSize.set(512,512);key.shadow.camera.left=-7;key.shadow.camera.right=7;key.shadow.camera.top=7;key.shadow.camera.bottom=-7;
key.shadow.camera.near=.1;key.shadow.camera.far=25;key.shadow.normalBias=.014;key.shadow.bias=-.00008;key.shadow.radius=2.5;key.shadow.blurSamples=4;
scene.add(key);scene.add(key.target);
const fill=new THREE.DirectionalLight(0xf4f3f0,.45);fill.position.set(5,5,-4);scene.add(fill);
scene.add(new THREE.HemisphereLight(0xfffdf7,0x777970,.18));
window.ready=(async()=>{
 const [gltf,zoom]=await Promise.all([new GLTFLoader().loadAsync('assets/cena-animada.glb'),fetch('assets/camera-zoom.json').then(r=>r.json())]);
 scene.add(gltf.scene);
 gltf.scene.traverse(o=>{if(o.isMesh){o.castShadow=o.name!=='PISO';o.receiveShadow=true;}});
 const camera=gltf.cameras[0];if(!camera)throw Error('Câmera 3D ausente no GLB.');
 const mixer=new THREE.AnimationMixer(gltf.scene);
 for(const clip of gltf.animations){const a=mixer.clipAction(clip);a.setLoop(THREE.LoopOnce,1);a.clampWhenFinished=true;a.play();}
 const roots=['FATURA_PRINCIPAL','TORNEIRA_CLASSICA','FOGAO','MEDIDOR','PLATAFORMAS_E_TUBULACOES','CARTAO_SEGUNDA','CARTAO_DOMINGO'].map(n=>gltf.scene.getObjectByName(n));
 const drop=gltf.scene.getObjectByName('GOTA'),flame=gltf.scene.getObjectByName('CHAMAS');
 window.renderFrame=t=>{
  mixer.setTime(Math.min(49.999,Math.max(0,t)));
  for(const o of roots)if(o)o.visible=Math.abs(o.scale.x)>.0001;
  if(drop)drop.visible=Math.abs(drop.scale.x)>.01;
  if(flame)flame.visible=Math.abs(flame.scale.z)>.001;
  const q=Math.min(zoom.length-2,Math.floor(t*30)),mix=t*30-q;
  const scale=THREE.MathUtils.lerp(zoom[q][1],zoom[q+1][1],mix);
  camera.top=scale/2;camera.bottom=-scale/2;camera.right=scale*16/9/2;camera.left=-camera.right;camera.updateProjectionMatrix();
  renderer.render(scene,camera);
 };
 window.renderFrame(2.5);
 return {animations:gltf.animations.length,camera:camera.name,triangles:renderer.info.render.triangles,calls:renderer.info.render.calls};
})();
