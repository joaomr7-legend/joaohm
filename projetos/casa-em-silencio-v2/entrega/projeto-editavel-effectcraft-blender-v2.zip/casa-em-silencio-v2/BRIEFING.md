# Escopo vigente — versão 2

- Horizontal 1920 × 1080, 50 s, 30 fps, sem áudio. Voz a ser fornecida pelo cliente.
- Todo conteúdo essencial na faixa central aproximada de 608 × 1080. Guias x=656,25..1263,75; margens sugeridas x=688..1232 e y=80..1000.
- Texto centralizado, objetos em coluna ou conjunto compacto. Nada essencial depende das laterais do master horizontal.
- Fundo off-white, grão e grade discretos; prata, grafite e sombras suaves. Fonte Inter como aproximação gratuita da referência; família original não identificada.
- Arquivo de referência recebido: 17,87 s, 720 × 1280, 25 fps, correspondente ao pin 933230354046673791. Analisado por amostragem até o fim, com maior densidade em transições. Som não inspecionado nem reutilizado.
- Tipografia compacta, palavras-chave em negrito, entradas curtas com desfoque/escala, objetos com volume e cartões. A paleta monocromática pedida foi mantida.
- EffectCraft: 81 camadas no CORE, master horizontal e composição vertical ligados ao mesmo conteúdo. Blender: geometria, materiais e luz; renders e abertura de papel reutilizados da base aprovada.
- Sem geração externa paga. Nenhuma mídia da referência incluída na entrega. Versão 1 preservada.

## Roteiro mantido
00–05: Poucas pessoas percebem isso...
05–09: Mas a sua casa fala com você.
09–13: Ela fala na conta de energia que aumenta.
13–16: Na água desperdiçada.
16–19: E no gás que acaba.
19–22: O problema? Ela sempre fala tarde demais.
22–25: Hoje, a casa consome em silêncio. A conta é que grita.
25–33: Segunda-feira. Fatura aberta nas mãos.
33–41: Quarta-feira. Medidor e ponteiro.
41–46: Domingo. Chama se apaga.
46–50: Três surpresas. Uma única causa: Falta de informação.

Textos preservados, com novas quebras de linha. A montagem poderá precisar de ajustes temporais quando a voz chegar.
