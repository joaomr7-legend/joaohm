"""Recursos próprios de composição; modelos Blender e fontes permanecem editáveis."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, json, shutil, math
P=Path(__file__).resolve().parents[1]
OUT=P/'assets/composicao';OUT.mkdir(exist_ok=True)
info={}
def save(im,name,bbox=None):
    im.save(OUT/(name+'.png'));info[name]={'w':im.width,'h':im.height,'bbox':bbox}

for f in (P/'assets/renders').glob('*.png'):
    if f.stem.startswith('abertura-'):continue
    im=Image.open(f).convert('RGBA');b=im.getbbox();b=(max(0,b[0]-12),max(0,b[1]-12),min(im.width,b[2]+12),min(im.height,b[3]+12))
    save(im.crop(b),f.stem+'-cut',list(b))
frames=sorted((P/'assets/renders').glob('abertura-*.png'))
boxes=[Image.open(f).getbbox() for f in frames]
box=(min(b[0] for b in boxes)-10,min(b[1] for b in boxes)-10,max(b[2] for b in boxes)+10,max(b[3] for b in boxes)+10)
seq=P/'assets/abertura';seq.mkdir(exist_ok=True)
for f in frames:Image.open(f).crop(box).save(seq/f.name)
last=Image.open(seq/frames[-1].name);save(last,'fatura-aberta',list(box))
info['abertura']={'w':last.width,'h':last.height,'bbox':list(box),'frames':len(frames),'fps':14}

# Papel e grade sem aleatoriedade temporal; imagem decorativa própria.
rng=np.random.default_rng(1729)
yy,xx=np.mgrid[0:1080,0:1920]
dist=((xx-960)/1450)**2+((yy-460)/1200)**2
base=246-5*np.clip(dist,0,1)+rng.normal(0,.6,(1080,1920))
rgb=np.clip(np.stack([base,base-.7,base-4.3],axis=-1),0,255).astype(np.uint8)
im=Image.fromarray(rgb);d=ImageDraw.Draw(im)
for x in range(0,1920,48):d.line((x,0,x,1080),fill=(238,239,233),width=1)
for y in range(0,1080,48):d.line((0,y,1920,y),fill=(238,239,233),width=1)
for x in range(96,1920,192):
 for y in range(96,1080,192):
  d.line((x-3,y,x+3,y),fill=(221,225,217));d.line((x,y-3,x,y+3),fill=(221,225,217))
save(im,'papel-grid')
save(im.crop((656,0,1264,1080)),'papel-core')

# Sombras difusas próprias, separadas das imagens 3D.
im=Image.new('RGBA',(600,160));d=ImageDraw.Draw(im);d.ellipse((80,61,520,95),fill=(25,29,30,45));im=im.filter(ImageFilter.GaussianBlur(22));save(im,'sombra-objeto')
im=Image.new('RGBA',(600,810));d=ImageDraw.Draw(im);d.rounded_rectangle((44,35,564,773),radius=14,fill=(30,34,35,34));im=im.filter(ImageFilter.GaussianBlur(17));save(im,'sombra-cartao')

# Ponteiro independente; o ponto de rotação fica em (12,126).
im=Image.new('RGBA',(24,146));d=ImageDraw.Draw(im);d.polygon([(10,128),(10,13),(12,0),(14,13),(14,128)],fill='#3b4246');d.ellipse((4,118,20,134),fill='#abb0b1');save(im,'ponteiro')

# Línguas de chama prateadas estilizadas, camada própria para animação e extinção.
im=Image.new('RGBA',(460,160));d=ImageDraw.Draw(im)
for i in range(19):
 a=i*math.tau/19;x=230+math.cos(a)*180;y=111+math.sin(a)*23
 h=64+12*math.sin(i*1.7)
 pts=[(x-9,y),(x-12,y-h*.28),(x-5,y-h*.7),(x+2,y-h),(x+8,y-h*.43),(x+11,y-h*.13),(x+7,y)]
 d.polygon(pts,fill=(115,124,130,156));d.ellipse((x-4,y-13,x+4,y+1),fill=(235,237,236,205))
im=im.filter(ImageFilter.GaussianBlur(.65));save(im,'chama-prata')
im=Image.new('RGBA',(250,300));d=ImageDraw.Draw(im)
for i in range(8):
 x=125+20*math.sin(i*1.2);y=260-i*26;d.ellipse((x-20,y-25,x+20,y+25),fill=(105,114,115,28))
save(im.filter(ImageFilter.GaussianBlur(13)),'fumaca')

# Onda de água com transparência nativa.
im=Image.new('RGBA',(260,70));d=ImageDraw.Draw(im);d.ellipse((5,5,255,65),outline=(100,111,109,100),width=2);save(im,'onda')
(OUT/'dimensoes.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,ensure_ascii=False))
