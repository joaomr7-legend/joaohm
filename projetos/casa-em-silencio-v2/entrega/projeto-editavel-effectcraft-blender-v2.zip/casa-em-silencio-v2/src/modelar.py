"""Blender 4.3: geometria e renders de estúdio, sem recursos externos."""
import bpy, math, os, sys
from mathutils import Vector
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/renders'
OUT.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
s = bpy.context.scene
s.render.engine = 'CYCLES'
s.cycles.samples = 96
s.cycles.use_denoising = False
s.render.threads_mode = 'FIXED'
s.render.threads = 5
s.render.resolution_x = 1300
s.render.resolution_y = 1300
s.render.resolution_percentage = 100
s.render.image_settings.file_format = 'PNG'
s.render.image_settings.color_mode = 'RGBA'
s.render.film_transparent = True
s.world.color = (0.5, 0.5, 0.5)
s.world.use_nodes = True
s.world.node_tree.nodes['Background'].inputs['Color'].default_value = (.70,.72,.74,1)
s.world.node_tree.nodes['Background'].inputs['Strength'].default_value = .65
s.view_settings.view_transform = 'AgX'

def material(name, color, metal=0, rough=.3):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color,1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value = (*color,1)
    bs.inputs['Metallic'].default_value = metal
    bs.inputs['Roughness'].default_value = rough
    return m

silver = material('Prata escovada', (.48,.50,.52),.92,.22)
dark = material('Grafite acetinado',(.035,.041,.048),.8,.25)
black = material('Cerâmica carvão',(.014,.017,.020),.28,.23)
paper = material('Papel marfim',(.88,.87,.83),0,.62)
ink = material('Impressão grafite',(.035,.04,.045),.1,.48)
line = material('Impressão cinza claro',(.43,.44,.44),0,.6)
handmat = material('Mãos em cerâmica escura',(.045,.050,.057),.3,.33)
water = material('Gota de prata líquida',(.65,.69,.73),.94,.075)

def finish(o, mat, bevel=0):
    o.data.materials.append(mat)
    if bevel:
        mod=o.modifiers.new('Arestas de precisão','BEVEL'); mod.width=bevel; mod.segments=4
        o.modifiers.new('Normais ponderadas','WEIGHTED_NORMAL')
    if o.type=='MESH':
        for p in o.data.polygons: p.use_smooth=True
    return o

def cube(name, loc, scale, mat, bevel=.06):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=bpy.context.object; o.name=name
    o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    return finish(o,mat,bevel)

def cylinder(name,loc,radius,depth,mat,rot=None):
    bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=radius,depth=depth,location=loc)
    o=bpy.context.object; o.name=name
    if rot: o.rotation_euler=rot
    return finish(o,mat,.025)

def sphere(name,loc,scale,mat):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=32,location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale
    return finish(o,mat)

def pipe(name, points, radius,mat):
    c=bpy.data.curves.new(name,'CURVE'); c.dimensions='3D'; c.resolution_u=24
    c.bevel_depth=radius; c.bevel_resolution=6
    p=c.splines.new('BEZIER'); p.bezier_points.add(len(points)-1)
    for b,co in zip(p.bezier_points,points):
        b.co=co; b.handle_left_type='AUTO'; b.handle_right_type='AUTO'
    o=bpy.data.objects.new(name,c); bpy.context.collection.objects.link(o); c.materials.append(mat)
    return o

def text(body,loc,size,mat,rotation=(math.pi/2,0,0)):
    c=bpy.data.curves.new('Lettrage '+body,'FONT'); c.body=body; c.size=size; c.extrude=.001
    c.align_x='LEFT'; o=bpy.data.objects.new(body,c); bpy.context.collection.objects.link(o)
    o.location=loc; o.rotation_euler=rotation; c.materials.append(mat)
    return o

def light(name,loc,power,size,color=(1,1,1)):
    bpy.ops.object.light_add(type='AREA',location=loc)
    o=bpy.context.object; o.name=name; o.data.energy=power; o.data.shape='DISK';o.data.size=size
    o.data.color=color; o.rotation_euler=(Vector((0,0,1.5))-o.location).to_track_quat('-Z','Y').to_euler()

light('Softbox principal',(-4,-4,7),650,5)
light('Faixa lateral',(4,1,5),850,3)
light('Preenchimento',(0,-5,2),180,3)
bpy.ops.object.camera_add(location=(5,-8,5.8))
cam=bpy.context.object; s.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=5.8

def camera(loc, target, scale):
    cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.ortho_scale=scale

def begin(name):
    c=bpy.data.collections.new(name); s.collection.children.link(c)
    for layer in bpy.context.view_layer.layer_collection.children:
        if layer.name==name: bpy.context.view_layer.active_layer_collection=layer
    return c

groups=[]
def render(name, col,loc,target,scale):
    for c in groups: c.hide_render=c!=col
    camera(loc,target,scale)
    s.render.filepath=str(OUT/(name+'.png'))
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'src/objetos.blend'))
    bpy.ops.render.render(write_still=True)

# Torneira: cano com espessura real, aerador e alavanca independente.
c=begin('01 | Torneira');groups.append(c)
cylinder('Base',(0,0,.12),.44,.2,dark)
cylinder('Roseta',(0,0,.26),.32,.11,silver)
cylinder('Coluna',(0,0,.92),.20,1.28,silver)
pipe('Bica curva',[(0,0,1.42),(0,0,2.17),(.05,0,2.6),(.45,0,2.88),(1.01,0,2.77),(1.16,0,2.4)],.155,silver)
cylinder('Aerador',(1.16,0,2.35),.167,.14,dark)
cylinder('Face do aerador',(1.16,0,2.27),.133,.02,black)
cylinder('Tampa superior',(-.02,0,1.45),.24,.12,dark)
pipe('Alavanca',[(0,0,1.53),(-.08,0,1.65),(-.55,0,1.68)],.055,silver)
render('torneira',c,(5,-8,5.0),(.35,0,1.5),4.4)

# Gota: malha de revolução com ponta, sem esfera disfarçada.
c=begin('02 | Gota');groups.append(c)
verts=[];faces=[];N=64;R=40
for j in range(R+1):
    t=j/R
    z=.65*t
    r=.22*math.sin(math.pi*t)**.8*(1-.65*t)
    for k in range(N):
        a=k*math.tau/N;verts.append((r*math.cos(a),r*math.sin(a),z))
for j in range(R):
    for k in range(N):
        a=j*N+k;b=j*N+(k+1)%N;faces.append((a,b,b+N,a+N))
mesh=bpy.data.meshes.new('Gota');mesh.from_pydata(verts,[],faces);mesh.update()
o=bpy.data.objects.new('Gota',mesh);bpy.context.collection.objects.link(o);finish(o,water)
render('gota',c,(2,-5,2), (0,0,.32),.95)

# Queimador: mesa, grelha, anéis e saídas de gás.
c=begin('03 | Queimador');groups.append(c)
cube('Mesa do fogão',(0,0,.06),(3.6,3.1,.18),silver,.16)
cube('Vidro embutido',(0,0,.17),(3.3,2.8,.12),black,.14)
cylinder('Anel inferior',(0,0,.30),.89,.17,dark)
cylinder('Anel de gás',(0,0,.42),.76,.12,silver)
for i in range(40):
    a=i*math.tau/40
    o=cube('Saída de gás',(math.cos(a)*.755,math.sin(a)*.755,.43),(.07,.035,.065),black,.008)
    o.rotation_euler.z=a
cylinder('Tampa do queimador',(0,0,.51),.69,.10,black)
for angle in [0,math.pi/2,math.pi,3*math.pi/2]:
    o=cube('Suporte de panela',(math.cos(angle)*1.09,math.sin(angle)*1.09,.65),(1.06,.14,.24),dark,.035)
    o.rotation_euler.z=angle
cylinder('Comando',(1.28,-1.1,.31),.19,.23,dark)
cube('Marca do comando',(1.28,-1.1,.44),(.025,.21,.01),silver,.005)
render('fogao',c,(5,-7,7),(0,0,.3),5.1)

# Medidor circular com visor mecânico. Ponteiro composto na montagem.
c=begin('04 | Medidor');groups.append(c)
cylinder('Corpo do medidor',(0,0,0),1.25,.48,dark,(math.pi/2,0,0))
cylinder('Aro de aço',(0,-.27,0),1.20,.12,silver,(math.pi/2,0,0))
cylinder('Mostrador',(0,-.345,0),1.08,.03,paper,(math.pi/2,0,0))
for i in range(60):
    a=i*math.tau/60
    x,z=math.sin(a)*.91,math.cos(a)*.91
    o=cube('Escala',(x,-.373,z),(.014 if i%5 else .025,.008,.07 if i%5 else .15),ink,.001)
    o.rotation_euler.y=a
cube('Janela de leitura',(0,-.38,.30),(1.33,.025,.35),dark,.045)
text('0 0 1 2 8 4',(-.58,-.405,.21),.21,paper)
text('m³',(.45,-.39,-.03),.11,ink)
text('FLUXO',(-.22,-.39,-.75),.12,line)
cylinder('Pivô',(0,-.41,-.30),.075,.055,silver,(math.pi/2,0,0))
for x in [-1.58,1.58]:
    cylinder('Conexão',(x,0,0),.29,.68,silver,(0,math.pi/2,0))
    cylinder('Porca',(x*.83,0,0),.36,.16,dark,(0,math.pi/2,0))
render('medidor',c,(.8,-9,3),(0,0,0),4.5)

# Fatura: placa curva de papel com impressão geometricamente ligada à folha.
c=begin('05 | Fatura');groups.append(c)
o=cube('Papel principal',(0,0,1.65),(2.25,.035,3.1),paper,.045)
o.rotation_euler.y=math.radians(-5)
text('ENERGIA',(-.91,-.04,2.75),.22,ink)
text('DEMONSTRATIVO',(-.89,-.04,2.54),.082,line)
for j,width in enumerate([1.1,.75,1.65,1.4,1.67]):
    cube('Linha impressa',(-.88+width/2,-.047,2.15-j*.16),(width,.008,.025),line,.003)
text('CONSUMO',(-.88,-.05,1.05),.10,ink)
for j,h in enumerate([.16,.22,.29,.39,.51,.67]):
    cube('Barra de consumo',(-.78+j*.28,-.055,.52+h/2),(.16,.012,h),ink,.01)
for i in range(37):
    x=-.86+i*.046
    cube('Código de barras',(x,-.05,.27),(.013 if i%3 else .024,.01,.17),ink,.001)
# canto superior destacado, dobra real
o=cube('Canto de papel',(1.01,-.07,3.10),(.25,.028,.25),paper,.012)
o.rotation_euler=(.2,0,.1)
render('fatura',c,(3.8,-10,5.0),(0,0,1.6),4.4)

# Duas mãos escultóricas, palmas e falanges com volume, abertura em torno da folha.
c=begin('06 | Fatura nas mãos');groups.append(c)
for original in groups[-2].objects:
    ob=original.copy();ob.data=original.data.copy();c.objects.link(ob)
for side in [-1,1]:
    sphere('Palma',(side*1.16,-.03,.85),(.29,.18,.45),handmat)
    o=cube('Punho',(side*1.22,.06,.27),(.38,.29,.8),handmat,.15)
    o.rotation_euler.y=side*.17
    for j in range(4):
        x=side*(1.17+j*.075)
        pipe('Dedo articulado',[(x,.03,.88),(x,.10,1.18+j*.035),(side*1.06,-.06,1.30+j*.035),(side*.98,-.12,1.19+j*.035)],.066,handmat)
    pipe('Polegar',[(side*1.03,-.10,.85),(side*.90,-.17,1.03),(side*.89,-.16,1.28)],.085,handmat)
render('fatura-maos',c,(3.0,-10,5.1),(0,0,1.65),4.8)

# Todos os grupos preservados no arquivo editável, visibilidade por coleção.
for c in groups: c.hide_render=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'src/objetos.blend'))
print('RENDERS_CONCLUIDOS')
