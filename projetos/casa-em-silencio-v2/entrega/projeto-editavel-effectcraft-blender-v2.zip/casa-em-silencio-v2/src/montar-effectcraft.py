"""Composição nativa do EffectCraft: textos, keyframes e elementos separados.

Nenhuma imagem da referência é incorporada ao projeto ou à entrega.
"""
from pathlib import Path
from PIL import ImageFont
import json, math, subprocess, os

P=Path(__file__).resolve().parents[1]
CLI=os.environ.get('EFFECTCRAFT_CLI','/workspace/tools/bin/effectcraft-cli')
D=json.loads((P/'assets/composicao/dimensoes.json').read_text())
steps=[]; bounds=[]; serial=0
FONT=P/'assets/fonts/Inter[opsz,wght].ttf'
def cmd(command,**params):steps.append({'command':command,'params':params})
def prop(name,path,value):cmd('prop.set',layer=name,path=path,value=value)
def key(name,path,t,value):cmd('prop.addKey',layer=name,path=path,time=round(t,6),value=value)
def lerp(a,b,t):
    if isinstance(a,(list,tuple)):return [lerp(x,y,t) for x,y in zip(a,b)]
    return a+(b-a)*t
def ease(t):return t*t*t*(t*(t*6-15)+10)
def tween(name,path,a,b,v0,v1,n=7):
    for i in range(n):key(name,path,a+(b-a)*i/(n-1),lerp(v0,v1,ease(i/(n-1))))
def visibility(name,s,e,opacity=100,enter=.32,exit=.16):
    cmd('layer.timing',layers=[name],**{'in':s,'out':min(e,50)})
    tween(name,'transform/opacity',s,s+enter,0,opacity,5)
    if e<50:tween(name,'transform/opacity',e-exit,e,opacity,0,4)
def name(prefix):
    global serial
    serial+=1;return f'{serial:03d} | {prefix}'
def item(asset,n,x,y,w,s,e,fade=True,rotation=0,drift=0,opacity=100):
    meta=D[asset];h=meta['h']*w/meta['w']
    source='abertura-[00-24].png' if asset=='abertura' else asset+'.png'
    cmd('layer.addItem',item=source,position=[x,y])
    cmd('layer.rename',name=n)
    if asset=='abertura':cmd('layer.timing',layers=[n],start=s)
    scale=100*w/meta['w'];prop(n,'transform/scale',[scale,scale])
    prop(n,'transform/rotation',rotation)
    if fade:visibility(n,s,e,opacity)
    else:cmd('layer.timing',layers=[n],**{'in':s,'out':e});prop(n,'transform/opacity',opacity)
    if drift:
        for i in range(7):
            t=s+(e-s)*i/6;key(n,'transform/position',t,[x,y+drift*math.sin(i/6*math.pi)])
            key(n,'transform/rotation',t,rotation+.6*math.sin(i/6*math.pi))
    bounds.append({'layer':n,'type':'asset','asset':asset,'s':s,'e':e,'x':x,'y':y,'w':w,'h':h,'rotation':rotation,'drift':drift})
    return n
def text(body,y,size,s,e,bold=False,delay=0,color='#292c2e',track=-18):
    f=ImageFont.truetype(str(FONT),size)
    while f.getlength(body)>490:size-=1;f=ImageFont.truetype(str(FONT),size)
    n=name(body);s+=delay
    cmd('layer.newText',name=n,text=body,font='Inter',style='Bold' if bold else 'Regular',size=size,fill=color,justify='center',position=[960,y],tracking=track)
    visibility(n,s,e,enter=.34)
    tween(n,'transform/position',s,s+.42,[960,y+17],[960,y])
    tween(n,'transform/scale',s,s+.38,[96,96],[100,100])
    cmd('effect.apply',effect='Gaussian Blur',layers=[n])
    tween(n,'effects/#1/blurriness',s,s+.28,6,0,4)
    bounds.append({'layer':n,'type':'text','text':body,'s':s,'e':e,'x':960,'y':y,'w':f.getlength(body),'h':size*1.35,'size':size})
    return n
def label(body,y,s,e,delay=0):return text(body,y,13,s,e,delay=delay,color='#727974',track=110)
def lines(entries,s,e):
    for i,(body,y,size,bold) in enumerate(entries):text(body,y,size,s,e,bold,delay=.1+i*.085)
def shadow(x,y,w,s,e,alpha=100):item('sombra-objeto',name('Sombra difusa'),x,y,w,s,e,opacity=alpha)
def hero(asset,s,e,w=350,y=650,rotation=-1):
    shadow(960,886,480,s,e)
    return item(asset,name('Objeto / '+asset),960,y,w,s+.12,e,rotation=rotation,drift=-6)
def shape(n,x,y,w,h,s,e,fill='#f9f8f3'):
    cmd('layer.newShape',name=n,kind='rounded',size=[w,h],fill=fill,strokeWidth=0,position=[x,y])
    visibility(n,s,e)
def panel(s,e,day,number,category):
    item('sombra-cartao',name('Sombra do cartão'),960,552,600,s,e)
    n=name('Cartão '+day);shape(n,960,548,520,738,s,e)
    tween(n,'transform/position',s,s+.5,[977,548],[960,548])
    label(number+' / '+category,223,s,e,.05)
    text(day,306,48,s,e,True,.12)
def flame(s,e,cx=960,cy=568,w=192,off=2):
    n=item('chama-prata',name('Chama / extinção'),cx,cy,w,s,e,fade=False)
    for i in range(max(2,int(off*9))):
        t=s+i/9
        if t>=s+off:break
        key(n,'transform/opacity',t,88+10*math.sin(i*1.9))
        a=100*w/D['chama-prata']['w'];key(n,'transform/scale',t,[a,a*(1+.06*math.sin(i*2.2))])
    tween(n,'transform/opacity',s+off,min(s+off+.14,e),94,0,5)
    n=item('fumaca',name('Fumaça após extinção'),cx,cy-20,135,s+off+.05,min(e,s+off+1.45),fade=False)
    tween(n,'transform/opacity',s+off+.05,s+off+.3,0,28,4)
    tween(n,'transform/opacity',s+off+.3,min(e,s+off+1.45),28,0,6)
    tween(n,'transform/position',s+off+.05,min(e,s+off+1.45),[cx,cy-10],[cx+6,cy-64],7)

cmd('comp.new',name='A CASA EM SILÊNCIO | 16x9 + SAFE 9x16',width=1920,height=1080,frameRate=30,duration=50,background='#f1f0eb')
for x in [656.25,688,960,1232,1263.75]:cmd('view.addGuide',orientation='vertical',position=x)
for y in [80,540,1000]:cmd('view.addGuide',orientation='horizontal',position=y)
cmd('view.guides',value=True)
for t,comment in [(0,'Poucas pessoas percebem isso...'),(5,'Mas a sua casa fala com você.'),(9,'Energia'),(13,'Água'),(16,'Gás'),(19,'Tarde demais'),(22,'A conta é que grita.'),(25,'Segunda-feira.'),(33,'Quarta-feira.'),(41,'Domingo.'),(46,'Três surpresas. Uma única causa: Falta de informação.')]:cmd('comp.addMarker',time=t,comment=comment)
files=[str(P/'assets/composicao'/(asset+'.png')) for asset in D if asset!='abertura']
cmd('file.import',paths=files,sequence=False,addToComp=False)
cmd('file.import',paths=[str(P/'assets/abertura/abertura-00.png')],sequence=True,frameRate=14,addToComp=False)

# Fundo e identificação: somente decoração ocupa as laterais do master horizontal.
n=item('papel-core',name('Papel / grade central'),960,540,608,0,50,fade=False)
label('A CASA EM SILÊNCIO',135,0,50,.2)

# 00–05. Abertura compacta, hierarquia inspirada na referência.
lines([('Poucas pessoas',284,43,False),('percebem isso...',345,56,True)],0,5)
hero('fatura-cut',.35,5,330,663,-2)

# 05–09. Três sinais em uma unidade central, com trajetórias contidas na área segura.
lines([('Mas a sua casa',282,43,False),('fala com você.',345,59,True)],5,9)
shadow(960,807,500,5,9)
for asset,x,y,w,rot in [('fatura-cut',803,623,143,-6),('torneira-cut',1104,605,140,3),('fogao-cut',960,759,244,-2)]:
    n=item(asset,name('Conjunto / '+asset),x,y,w,5.25,9,rotation=rot,drift=-5)
    tween(n,'transform/position',5.25,5.85,[x+(x-960)*.13,y+20],[x,y])

# 09–13. Energia.
lines([('Ela fala na conta',222,41,False),('de energia',278,51,False),('que aumenta.',343,60,True)],9,13)
hero('fatura-cut',9.25,13,334,658,-1)
label('ENERGIA',930,9,13,.35)

# 13–16. Gota independente do corpo da torneira.
lines([('Na água',282,44,False),('desperdiçada.',344,58,True)],13,16)
hero('torneira-cut',13.1,16,264,648,0)
# Posição do aerador projetada a partir do render Blender recortado.
scale=264/D['torneira-cut']['w'];bb=D['torneira-cut']['bbox'];cx=960+(850-(bb[0]+bb[2])/2)*scale;cy=648+(492-(bb[1]+bb[3])/2)*scale
for i,s in enumerate([13.35,14.72]):
    end=min(s+1.1,16);n=item('gota-cut',name('Gota '+str(i)),cx,cy+15,16,s,end,fade=False)
    tween(n,'transform/position',s,s+.8,[cx,cy+15],[cx,867],10)
    tween(n,'transform/opacity',s+.69,s+.84,100,0,4)
    item('onda',name('Onda '+str(i)),cx,878,130,s+.78,min(16,s+1.1),opacity=38)
label('ÁGUA',930,13,16,.35)

# 16–19. Chama cessa e produz fumaça sutil.
lines([('E no gás',282,44,False),('que acaba.',344,61,True)],16,19)
hero('fogao-cut',16.12,19,448,661,-1)
flame(16.35,19,cy=614,w=178,off=1.25)
label('GÁS',930,16,19,.35)

# 19–22. Pausa tipográfica, como os momentos de texto isolado da referência.
lines([('O problema?',403,43,False),('Ela sempre fala',480,42,False),('tarde demais.',553,62,True)],19,22)
for asset,x,w in [('fatura-cut',843,64),('torneira-cut',960,53),('fogao-cut',1078,86)]:item(asset,name('Símbolo / '+asset),x,758,w,19.45,22,opacity=70)

# 22–25. Ênfase em duas mensagens sequenciais, preservando o texto aprovado.
lines([('Hoje, a casa consome',297,37,False),('em silêncio.',356,58,True),('A conta é que grita.',538,46,True)],22,25)
hero('fatura-cut',22.4,25,166,763,-3)

# 25–33. Segunda-feira: folha articulada 3D nas mãos, depois sustentada aberta.
panel(25,33,'Segunda-feira.','01','ENERGIA')
shadow(960,833,447,25,33)
s=25.46;e=s+25/14
item('abertura',name('Fatura / abertura 3D'),960,610,416,s,e,fade=False)
item('fatura-aberta',name('Fatura / aberta'),960,610,416,e,33,fade=False,drift=-3)
label('CONTA DE ENERGIA',867,25.7,33)

# 33–41. Quarta-feira: medidor em funcionamento com ponteiro separado.
panel(33,41,'Quarta-feira.','02','ÁGUA')
shadow(960,802,470,33,41)
item('medidor-cut',name('Medidor / corpo'),960,609,456,33.2,41,drift=0)
meta=D['medidor-cut'];scale=456/meta['w'];bb=meta['bbox'];px=960+(640-(bb[0]+bb[2])/2)*scale;py=609+(770-(bb[1]+bb[3])/2)*scale
n=item('ponteiro',name('Medidor / ponteiro'),px,py,15,33.35,41)
prop(n,'transform/anchor',[12,126])
for i in range(34):key(n,'transform/rotation',33.35+i*(41-33.35)/33,-35+i*39)
label('O FLUXO CONTINUA.',867,33.6,41)

# 41–46. Domingo: extinção mais súbita, breve sustentação do fogão apagado.
panel(41,46,'Domingo.','03','GÁS')
shadow(960,800,470,41,46)
item('fogao-cut',name('Fogão / domingo'),960,625,467,41.2,46,drift=-3)
flame(41.4,46,cy=578,w=189,off=2.05)
label('A CHAMA SE APAGA.',867,43.6,46)

# 46–50. Convergência em um conjunto, todas as frases na área vertical.
shadow(960,506,480,46,50)
for asset,x,y,w,rot in [('fatura-cut',832,381,132,-5),('torneira-cut',1095,375,119,2),('fogao-cut',960,468,225,-1)]:
    n=item(asset,name('Convergência / '+asset),x,y,w,46.08,50,rotation=rot)
    tween(n,'transform/position',46.08,46.85,[960+(x-960)*1.42,y+18],[x,y])
text('Três surpresas.',608,47,46.12,50,False,.15)
text('Uma única causa:',671,30,46.4,50,False,.25,color='#69716c')
text('Falta de',754,58,46.65,50,True,.3)
text('informação.',819,64,46.65,50,True,.4)

# Identificação discreta do capítulo, dentro da área protegida.
for s,e,num in [(0,25,'01'),(25,46,'02'),(46,50,'03')]:label(num,981,s,e,.1)

# O conteúdo central é uma precomposição nativa, reutilizada nos dois formatos.
# Renderizar efeitos e texto em 608px reduz buffers intermediários sem reamostrar o master.
CORE='CORE_CENTRAL_EDITAVEL_608x1080'
steps[0]['params'].update(name=CORE,width=608)
for step in steps:
    p=step['params'];c=step['command']
    if c=='view.addGuide' and p.get('orientation')=='vertical':p['position']-=656
    if isinstance(p.get('position'),list):p['position'][0]-=656
    if p.get('path')=='transform/position' and isinstance(p.get('value'),list):p['value'][0]-=656
cmd('comp.new',name='MASTER_HORIZONTAL_1920x1080',width=1920,height=1080,frameRate=30,duration=50,background='#f1f0eb')
cmd('layer.addItem',item='papel-grid.png',position=[960,540],duration=50)
cmd('layer.rename',name='FUNDO_EDITORIAL')
cmd('layer.addItem',item=CORE,position=[960,540],duration=50)
cmd('layer.rename',name='ABRIR PARA EDITAR TEXTOS E OBJETOS')
for x in [656.25,688,960,1232,1263.75]:cmd('view.addGuide',orientation='vertical',position=x)
for y in [80,540,1000]:cmd('view.addGuide',orientation='horizontal',position=y)
cmd('comp.new',name='VERTICAL_1080x1920',width=1080,height=1920,frameRate=30,duration=50,background='#f1f0eb')
cmd('layer.addItem',item=CORE,position=[540,960],duration=50)
cmd('layer.rename',name='MESMO_CONTEUDO_CENTRAL')
prop('MESMO_CONTEUDO_CENTRAL','transform/scale',[1080/608*100,1920/1080*100])
cmd('comp.open',comp='MASTER_HORIZONTAL_1920x1080')

output=P/'filme-centralizado.ecproj'
script=P/'src/montagem-effectcraft.json'
script.write_text(json.dumps(steps,ensure_ascii=False,separators=(',',':')))
(P/'src/limites-composicao.json').write_text(json.dumps(bounds,ensure_ascii=False,indent=2))
res=subprocess.run([CLI,'exec','file.runScript',json.dumps({'path':str(script)}),'--empty','--save-as',str(output),'--json'],capture_output=True,text=True,cwd=P)
(P/'src/montagem.log').write_text(res.stdout+'\n'+res.stderr)
if res.returncode:
    print(res.stdout[-3000:]);print(res.stderr[-3000:]);raise SystemExit(res.returncode)
result=json.loads(res.stdout)
# Caminhos relativos são resolvidos pelo EffectCraft a partir do .ecproj (#652).
# Isso permite extrair o ZIP em outro computador sem reconexão manual de mídias.
document=json.loads(output.read_text())
def portable(v):
    if isinstance(v,str) and v.startswith(str(P)+'/assets/'):return v[len(str(P))+1:]
    if isinstance(v,list):return [portable(x) for x in v]
    if isinstance(v,dict):return {k:portable(x) for k,x in v.items()}
    return v
output.write_text(json.dumps(portable(document),ensure_ascii=False,indent=2))
print('Montagem nativa salva:',output)
print('Comandos:',len(steps),'elementos:',len(bounds),'passos executados:',result.get('result',{}).get('steps'))
