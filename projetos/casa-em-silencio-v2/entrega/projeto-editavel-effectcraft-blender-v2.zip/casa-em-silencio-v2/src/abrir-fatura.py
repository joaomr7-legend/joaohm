"""Sequência de abertura de papel: dobradiça real, frente impressa e verso marfim."""
import bpy, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'src/objetos.blend'))
s=bpy.context.scene
s.cycles.samples=32
s.cycles.use_denoising=False
s.render.resolution_x=1000
s.render.resolution_y=1000
col=bpy.data.collections['06 | Fatura nas mãos']
for c in bpy.data.collections:
    if ' | ' in c.name:c.hide_render=c!=col
for o in list(col.objects):
    if not any(k in o.name for k in ['Palma','Punho','Dedo','Polegar']):o.hide_render=True
for layer in bpy.context.view_layer.layer_collection.children:
    if layer.name==col.name:bpy.context.view_layer.active_layer_collection=layer

tex=bpy.data.images.load(str(ROOT/'assets/fatura-impressao.png'))
m=bpy.data.materials.new('Papel impresso UV');m.use_nodes=True
nodes=m.node_tree.nodes;bs=nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.65
im=nodes.new('ShaderNodeTexImage');im.image=tex;m.node_tree.links.new(im.outputs['Color'],bs.inputs['Base Color'])
paper=bpy.data.materials.get('Papel marfim')
NX,NZ=16,96
verts=[(0,0,0) for _ in range((NX+1)*(NZ+1))];faces=[]
for j in range(NZ):
 for i in range(NX):
  a=j*(NX+1)+i;faces.append((a,a+1,a+NX+2,a+NX+1))
mesh=bpy.data.meshes.new('Folha articulada');mesh.from_pydata(verts,[],faces);mesh.update()
o=bpy.data.objects.new('Fatura abrindo',mesh);col.objects.link(o);o.data.materials.append(m);o.data.materials.append(paper)
uv=mesh.uv_layers.new()
for poly in mesh.polygons:
 for li in poly.loop_indices:
  vi=mesh.loops[li].vertex_index;uv.data[li].uv=(vi%(NX+1)/NX,vi//(NX+1)/NZ)
for poly in mesh.polygons:poly.use_smooth=True
sol=o.modifiers.new('Espessura do papel','SOLIDIFY');sol.thickness=.012;sol.material_offset=1
for frame in range(25):
 p=frame/24;p=p*p*p*(p*(p*6-15)+10);a=(1-p)*math.pi*.96
 for j in range(NZ+1):
  z=.10+3.10*j/NZ;d=max(0,z-1.65)
  for i in range(NX+1):
   x=-1.125+2.25*i/NX
   # A dobra afasta-se da metade fixa; a borda recebe leve curvatura de papel.
   yy=-math.sin(a)*d-.025-.023*math.sin(i/NX*math.pi)
   zz=z-d+math.cos(a)*d
   mesh.vertices[j*(NX+1)+i].co=(x,yy,zz)
 mesh.update()
 s.render.filepath=str(ROOT/'assets/renders'/f'abertura-{frame:02d}.png')
 bpy.ops.render.render(write_still=True)
 if frame==24:
  tex.pack();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'src/abertura-fatura.blend'))
print('ABERTURA_CONCLUIDA')
