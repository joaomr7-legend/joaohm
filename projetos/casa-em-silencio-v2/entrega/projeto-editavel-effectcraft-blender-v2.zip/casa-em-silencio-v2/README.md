# A casa em silêncio — versão 2

Projeto nativo do EffectCraft: 50 segundos, 30 fps, sem áudio, com texto e animação editáveis e objetos próprios do Blender.

## Abrir e editar
1. Extraia o ZIP completo, mantendo assets/ ao lado de filme-centralizado.ecproj.
2. Abra **filme-centralizado.ecproj** no EffectCraft 0.14.0 ou posterior.
3. Abra **CORE_CENTRAL_EDITAVEL_608x1080** para editar textos e objetos: são 81 camadas nomeadas, com keyframes e tempos de entrada/saída.
4. **MASTER_HORIZONTAL_1920x1080** e **VERTICAL_1080x1920** reutilizam o mesmo CORE. Alterações no CORE aparecem nos dois formatos.

Os arquivos Blender estão em src/objetos.blend e src/abertura-fatura.blend. Os renders são camadas separadas no EffectCraft. Não foi colocado um único vídeo achatado no lugar das camadas.

Os caminhos das mídias são relativos. A transferência do projeto e assets/ para outra pasta foi testada sem mídia ausente. Caso o editor solicite reconexão, selecione assets/ na reconexão de arquivos.

## Fonte e referência
Inter Regular/Bold é a aproximação gratuita adotada para a tipografia da referência. O nome da fonte original não pôde ser confirmado. A fonte e sua licença estão em assets/fonts; instale Inter se necessário. O EffectCraft também fornece Inter como fonte interna.

O vídeo enviado orientou tipografia, composição e movimento; nenhum quadro, som, marca ou recorte dele foi incluído na entrega. Veja ANALISE-REFERENCIA.md. A paleta monocromática foi preservada.

## Exportar
Na interface, selecione uma composição e a fila de renderização, com áudio desativado. Pelo CLI:

    effectcraft-cli render filme-centralizado.ecproj --comp MASTER_HORIZONTAL_1920x1080 --out horizontal.mp4 --audio off --progress
    effectcraft-cli render filme-centralizado.ecproj --comp VERTICAL_1080x1920 --out vertical.mp4 --audio off --progress

Na nuvem, o executável é /workspace/tools/bin/effectcraft-cli. A instalação do release oficial, com SHA-256 verificado, está em /workspace/tools/effectcraft/install.py. A interface gráfica requer desktop; o CLI foi validado sem janela.

## Regenerar a partir das fontes
Requer Python 3, dependências de requirements.txt e EffectCraft CLI. Execute:

    python3 src/preparar-recursos.py
    python3 src/montar-effectcraft.py

Esses comandos REGENERAM filme-centralizado.ecproj. Faça uma cópia antes se houver edições manuais. Fora da nuvem, defina EFFECTCRAFT_CLI com o caminho do executável. src/montagem-effectcraft.json registra os comandos usados na construção.

Para alterar o 3D e refazer os renders, execute blender -b -t 5 --python src/modelar.py e depois blender -b -t 5 --python src/abrir-fatura.py, seguidos pelos dois comandos Python acima. Não refaça os renders apenas para mudar o texto.

## Área segura e áudio
O conteúdo essencial foi recomposto na faixa central de aproximadamente 608 × 1080. Apenas fundo e grade seguem para as laterais do horizontal. O vertical escala o mesmo CORE; a diferença de arredondamento da largura é inferior a 0,1%.

A entrega não tem faixa de áudio. A sincronização fina com a narração depende da gravação ainda não fornecida. Leituras do medidor são ilustrações, não dados reais.
