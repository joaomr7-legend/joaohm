# Evidências e limites

- Exportação nativa pelo EffectCraft 0.14.0 concluída com código 0: master 1920 × 1080, 50 segundos, 30 fps, 1.500 quadros, áudio desativado.
- Decodificação integral do MP4 nativo com FFmpeg: código 0, sem erros.
- Projeto nativo com 81 camadas no CORE, dois formatos ligados ao mesmo conteúdo. Textos e keyframes permanecem editáveis.
- Arquivo e assets transferidos para outra pasta: nenhuma mídia ausente. Os caminhos das mídias no .ecproj são relativos.
- Verificação conservadora dos limites de 64 elementos essenciais dentro da faixa x=656..1264; amostras renderizadas em horizontal e vertical inspecionadas.
- Quadros inspecionados: abertura, água, fatura aberta/abrindo, medidor, chama apagada e final. A decodificação e os quadros amostrados não constituem inspeção visual integral em velocidade real.
- Referência analisada por amostragem até o fim, com maior densidade nas transições. Nenhuma mídia da referência distribuída no projeto.
- Inter é uma aproximação tipográfica; fonte exata da referência não identificada. Licenças de fontes e ícones preservadas.
- Os objetos são renders 3D próprios do Blender compostos em camadas, e não um render 3D integral de cada quadro. A folha usa uma sequência de 25 poses; chamas e fumaça são estilizadas em camadas separadas.
- A interface gráfica do EffectCraft não foi testada em desktop neste ambiente; comandos, projeto, renders e exportação pelo CLI foram exercitados.
- Sem voz, música ou efeitos sonoros; a sincronização fina aguarda a voz do cliente. Leituras do medidor são ilustrativas.

O MP4 horizontal distribuído recebe uma codificação de compatibilidade H.264 Main por FFmpeg, preservando a montagem exportada pelo EffectCraft. O MP4 vertical é uma adaptação do recorte central. O projeto também permite exportar vertical nativamente pela composição correspondente.
