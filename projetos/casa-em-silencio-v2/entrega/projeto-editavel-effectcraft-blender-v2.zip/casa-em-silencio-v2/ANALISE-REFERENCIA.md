# Referência e tradução visual

Arquivo vertical de 17,87 s, 720 × 1280, 25 fps. Análise por quadros amostrados ao longo da duração e a 5 quadros/s entre aproximadamente 6,2–9,2 s. Som não inspecionado. Tempos aproximados.

## Observado
- Texto sem serifa, compacto e central. Frases curtas, palavras-chave maiores e mais pesadas.
- Alternância claro/preto; vermelho para algumas ênfases.
- Objetos com aparência de volume e sombras. Motor e técnica originais não identificáveis somente pelo vídeo.
- Entradas por escala, deslocamento e desfoque; alternância de texto isolado com objeto e texto.
- Cerca de 6–7 s: objeto semelhante a uma maleta, com deslocamento e mudança de escala, acompanhado de texto.
- Cerca de 7–10 s: cartão cinza central, sombra, faixas curvas ao fundo e lista revelada progressivamente.
- Cerca de 12–13 s: palavra-chave pesada fecha uma frase.
- Cerca de 14–16 s: objeto grande na base e texto acima; a tipografia muda sem trocar todo o enquadramento.
- Final em tipografia compacta sobre preto.

## Adaptação
- Inter Regular/Bold, tamanho e peso por linha; fonte original não identificada.
- Grafite e negrito substituem a função do destaque vermelho, preservando a paleta aprovada.
- Fatura, torneira e fogão próprios do Blender substituem os objetos da referência.
- Cartões dos dias da semana, objetos e legendas em camadas separadas.
- Keyframes nativos e Gaussian Blur nas entradas dos textos.
- Pequenos deslocamentos e rotações com pausa para leitura.
- CORE vertical central reutilizado nos dois formatos.

Não foram copiados textos em inglês, marcas, recortes, objetos, imagens ou áudio do vídeo. O filme usa renders Blender em camadas; não é um render 3D integral de 1.500 quadros.
